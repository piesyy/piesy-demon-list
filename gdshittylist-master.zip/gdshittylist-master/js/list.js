const d = {
	"list": [
		/*=================================================================================*/
		{
                       "vids": [
			       {
				       "user": "XanPlayzGamez",
				       "link": "https://youtu.be/Vi6NIYsp0Sk",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "piesy",
				       "link": "https://youtu.be/30KjuruqQBA",
				       "percent": 100,
				       "hz": "300hz"
			       },
			       {
				       "user": "Plasmic",
				       "link": "https://www.youtube.com/watch?v=q_qw68G_c5Y&feature=youtu.be",
				       "percent": 100,
				       "hz": "300hz"
			       },
			       {
				       "user": "GDMeric",
				       "link": "https://www.youtube.com/watch?v=clQudjuJUTk&feature=youtu.be",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "Arcturus",
				       "link": "https://youtu.be/BBwbaXfxXkM",
				       "percent": 69,
				       "hz": "300hz"
			       },
			       {
				       "user": "Viewsonic",
				       "link": "https://www.youtube.com/watch?v=NIHY86mHMcA",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "X99",
				       "link": "https://youtu.be/Y0m_nRpMs1k",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "MrSaturnY",
				       "link": "https://youtu.be/UPunQ9xoCh0",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "Th13teen",
				       "link": "https://www.youtube.com/watch?v=OZREr1fyIgw&feature=youtu.be",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "Praerius",
				       "link": "https://www.youtube.com/watch?v=fHhUsxLsI50&t=1s",
				       "percent": 100,
				       "hz": "288hz"
			       },
			       {
				       "user": "Fhyron06",
				       "link": "https://www.youtube.com/watch?v=FzHsk5KUVMQ",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "SAMTHEMANK",
				       "link": "https://www.youtube.com/watch?v=I1586mqWgpw&feature=youtu.be",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "Lupe1204",
				       "link": "https://youtu.be/noLcpIpuWEU",
				       "percent": 100,
				       "hz": "Mobile"
			       },
			       {
				       "user": "DreamingLlama",
				       "link": "https://youtu.be/XLOmZj0PEko",
				       "percent": 100,
				       "hz": "120hz"
			       },
                       ],
                       "name": "Shitty Azure Flare",
                       "author": "Magma",
                       "more": "none",
                       "id": 63009517,
                       "pass": "Free to copy",
                       "percentToQualify": 45,
                       "verificationVid": "https://www.youtube.com/watch?v=I4IICgiqfbE&t=65s",
                       "key": 0
                },
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/bZ38Bk_mev8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=M4PVzQt9vAU",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/-txomH44h_s",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/zwTRBYKIlOo",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/glqx_WVzOWk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=FaIvB3wRWY0&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Moosh",
					"link": "https://www.youtube.com/watch?v=_njs7EUTO9I",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/KAyEJsWFPq8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=9lR8LAlMWSk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=2fq3rqNYoAY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Wadur",
					"link": "https://www.youtube.com/watch?v=Ic4ZjPLXtxI&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=AjcJt4FK7ns&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MrSaturnY",
					"link": "https://www.youtube.com/watch?v=W6RyzM-mluE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=XxrRfwPngzU",
					"percent": 100,
					"hz": "300hz"
				},
			],
			"name": "Shitty Infected Caverns",
			"author": "LJosh",
			"more": "none",
			"id": 61748947,
			"pass": "00011",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=hDFbSOlMUvE",
			"key": 1
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=f3eqo3n4qtM",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/ToIHi7iDIRs",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/EkcBDA4zcXU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Xanii",
					"link": "https://www.mediafire.com/file/yfswh8t0f3q9943/a.mp4/file",
					"percent": 100,
					"hz": "360hz"
				},
				{
					"user": "Surpl3x",
					"link": "https://youtu.be/kcYTwO4efk4",
					"percent": 64,
					"hz": "Mobile"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=FaIvB3wRWY0&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/rMLFHCCz2d8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "HamburgerMan",
					"link": "https://www.youtube.com/watch?v=8EH9WKfDiqw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=VVlo70fIQgk&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/NhblI6Pof9U",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Amza",
					"link": "https://youtu.be/iI1v8sv-n-I",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=W_rStwm0IL0&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "MySaturnY",
					"link": "https://youtu.be/DeLxGmZ_EdA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Covieta",
					"link": "https://youtu.be/CukyXoFJ4w4",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Erebus",
			"author": "LJosh",
			"more": "none",
			"id": 59560393,
			"pass": "000010",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=UBmcMgL0Pdg",
			"key": 2
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "GDTeaBag",
					"link": "https://www.youtube.com/watch?v=HLZe5440T_g",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MitSuS",
					"link": "https://youtu.be/gfnTyd28_3Y",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "PotatoManPlays",
					"link": "https://youtu.be/lge-geSZjRg",
					"percent": 93,
					"hz": "60hz"
				},
				{
					"user": "Aassbll",
					"link": "https://youtu.be/e4CleTX6wWs",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=8IYL1JJkjb4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Starprint",
					"link": "https://www.youtube.com/watch?v=nSmUgaWtwfE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "sandstormy",
					"link": "https://www.youtube.com/watch?v=7v2fT3H-Ffs&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/ZcN2N0CRsM8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Xanii",
					"link": "https://youtu.be/xIPlv1AKzB8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Catakill",
					"link": "https://youtu.be/ewrAMHjilHY",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/HE4KcTxwV68",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/Vh1Np-_D478",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/qNUxJrbC_8U",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=FaIvB3wRWY0&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/i44nBARc1Y8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/AaOX9ij5E6U",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/K3FPMghYbDA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Wadur",
					"link": "https://www.youtube.com/watch?v=wslabkKax7Q",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/zm-qy7oyMdc",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Migel",
					"link": "https://youtu.be/oI9bsoGgRsw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "CavEmaN_mElviN",
					"link": "https://www.youtube.com/watch?v=pStOWam44J4",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/MAZaHLKFgGc",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Arcturus",
					"link": "https://youtu.be/0ZwTMJKss0k",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/m7s1PZJONyQ",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=8xnPoVijVDs",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "lvcxs",
					"link": "https://youtu.be/Mgse7i0ihwE",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Kowareta",
			"author": "LJosh",
			"more": "none",
			"id": 59560367,
			"pass": "000009",
			"percentToQualify": 56,
			"verificationVid": "https://www.youtube.com/watch?v=-Zw0JVGLRlw",
			"key": 3
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "GDTeaBag",
					"link": "https://youtu.be/1Y1T2UdSCEY?t=1187",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/k4qQxni5ub0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=iUI5AANRfFI&t=2s",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Xanii",
					"link": "https://youtu.be/aMi6lsDYThQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/vXjPp_g_Vjo",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/m8QFrYZSdwI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Charlielance",
					"link": "https://youtu.be/qTXK4xkwWvg",
					"percent": 64,
					"hz": "120hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/BSmLPXshmM0",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "jToniX",
					"link": "https://youtu.be/7khUZ4PWqtk",
					"percent": 71,
					"hz": "144hz"
				},
				{
					"user": "Magma",
					"link": "https://youtu.be/029iKjYBwIY",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=pqkReFB6n2w&t=85s",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Wadur",
					"link": "https://www.youtube.com/watch?v=pqkReFB6n2w&t=85s",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Tai0",
					"link": "https://youtu.be/Zue-Isg--Ms",
					"percent": 100,
					"hz": "120hz"
				},
			],
			"name": "Shitty AfterCataBath",
			"author": "AcropolisBoy [LJosh]",
			"more": "none",
			"id": 57050573,
			"pass": "666666",
			"percentToQualify": 46,
			"verificationVid": "https://www.youtube.com/watch?v=gvkoieLhRLo",
			"key": 4
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=MXbEZ3iIeis",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/x6j3jM6oi-U",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Xanii",
					"link": "https://www.mediafire.com/file/3128yhf81tgxng8/mm.mp4/file",
					"percent": 100,
					"hz": "360hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/xwoEd3nJ5lo",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=etMLIreOdL8",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/G1Kw9mHZQgk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/tq3wL8VC9eI",
					"percent": 100,
					"hz": "288hz"
				},
			],
			"name": "Shitty Madmansion",
			"author": "Aassbll",
			"more": "none",
			"id": 57251824,
			"pass": "Free copy",
			"percentToQualify": 50,
			"verificationVid": "https://www.youtube.com/watch?v=x89Bj43uEDU",
			"key": 5
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Starprint",
					"link": "https://youtu.be/amrmrLjyy9Q",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=GJJoR3QzU1g",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "sandstormy",
					"link": "https://www.youtube.com/watch?v=_MyAoz49ebQ&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/bQP9DALtRyA",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Xanii",
					"link": "https://youtu.be/DC34bT4OKlE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/nMG6kGmMxHo",
					"percent": 100,
					"hz": "144hz"
				},
				{
                                        "user": "Asdner",
                                        "link": "https://youtu.be/LNFviXcUkeU",
                                        "percent": 61,
                                        "hz": "144hz"
                                },
				{
                                        "user": "GDMeric",
                                        "link": "https://youtu.be/3thN6SRQ-Uc",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
					"user": "nayf",
                                        "link": "https://youtu.be/h_pY3Wcq3wg",
                                        "percent": 100,
                                        "hz": "360hz"
				},
				{
					"user": "Magma",
                                        "link": "https://www.youtube.com/watch?v=fP-ywcYMj2k",
                                        "percent": 100,
                                        "hz": "300hz"
				},
				{
					"user": "HamburgerMan",
                                        "link": "https://www.youtube.com/watch?v=ppBpFy-_eHI",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/N7xfJ3cnHiw",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/Dr9CCbQBQ1k",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=IKddXU89Vjw&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/pr-nb7n_2-0",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=_o95uAZFsBA",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "lvcxs",
					"link": "https://www.youtube.com/watch?v=JCgFICK47cA",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "aurora",
					"link": "https://youtu.be/KPoUdXQ062o",
					"percent": 82,
					"hz": "240hz"
				},
				{
					"user": "Covieta",
					"link": "https://www.youtube.com/watch?v=SEtbwV63cgI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/o62wMSoTKgQ",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty The Golden",
			"author": "Serpyy",
			"more": "none",
			"id": 60988234,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://youtu.be/6mBUCC8dlCY",
			"key": 6
		},
		/*=================================================================================*/
		{
		
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=nDgBwccdbwk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/SySShiQWDJA",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Surpl3x",
					"link": "https://youtu.be/a7BoNtYmycM",
					"percent": 62,
					"hz": "Mobile"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=BxaadTZkpS8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/I0ZkTmg1MYU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://www.youtube.com/watch?v=VLOHaT0GLHo&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Moosh",
					"link": "https://www.youtube.com/watch?v=MAfShe_Y1qU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "crumche",
					"link": "https://cdn.discordapp.com/attachments/737134935881809963/737135132728623144/shitty_zaphkiel.mp4",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Wyaaronpc",
					"link": "https://youtu.be/MHWTGEgeuEo",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "HamburgerMan",
					"link": "https://www.youtube.com/watch?v=6hr-BW8wVi4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Hulunn",
					"link": "https://www.youtube.com/watch?v=e_R395pxhIA",
					"percent": 77,
					"hz": "300hz"
				},
				{
					"user": "Hixobit",
					"link": "https://www.youtube.com/watch?v=VxfW19iNr88&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Arcturus",
					"link": "https://youtu.be/Z-pDlFmgL4Q",
					"percent": 94,
					"hz": "300hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=hSV2erBIcdw",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/P8RlkDbb2HM",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Hulunn",
					"link": "https://www.youtube.com/watch?v=Dbmnczb7Dus&lc=Ugzvpcwm6QUeW5-nOAl4AaABAg",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=3Tktx5VyZFI&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Blathers",
					"link": "https://youtu.be/SoNZD4kPNCE",
					"percent": 66,
					"hz": "144hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=thTsf5Wuico",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Emonadeo",
					"link": "https://youtu.be/xC0B1t_m_7M",
					"percent": 58,
					"hz": "240hz"
				},
				{
					"user": "Migel",
					"link": "https://youtu.be/P2jtZjKyZwY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=9P_PZhQP2Es",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Tai0",
					"link": "https://youtu.be/zR4MabJXyfI",
					"percent": 59,
					"hz": "100hz"
				},
			],
			"name": "Shitty Zaphkiel",
			"author": "Serpyy [XanPlayzGamez]",
			"more": "none",
			"id": 60976052,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=fcqAzQsbVdY",
			"key": 7
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=owv5r9ZCvCs",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=3q1L67bqKe0",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://youtu.be/7CGDyvOWgKc",
					"percent": 72,
					"hz": "240hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=BnZexkV-QjI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/nriqQY8nh1c",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "1qawsz",
					"link": "https://youtu.be/bXZkAgWkHnw",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/2Ug__m4QqYc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Amedxx2y",
					"link": "https://youtu.be/O7OP_1gQRn0",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=M7KRfcBRr7Q",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "GDMeric",
					"link": "https://www.youtube.com/watch?v=pOVbTHRNn3s",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/XUxxTnbdwTY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=PmxUxHpq6iA&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/BX2H7S3n5cw",
					"percent": 100,
					"hz": "120hz"
				},
			],
			"name": "Shitty Triple Six",
			"author": "LJosh",
			"more": "none",
			"id": 59558238,
			"pass": "0005",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=oFUBGkctzR0",
			"key": 8
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=iaMO1bEwKYE",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/fv-LxzPubrU",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=JLHA0PdHatg",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "asdner",
					"link": "https://youtu.be/iu2KnUqX9Do",
					"percent": 94,
					"hz": "288hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=BxaadTZkpS8",
					"percent": 100,
					"hz": "240hz"
				},
				{	
					"user": "GDmeric",
					"link": "https://youtu.be/IPtkOZMWzYw",
					"percent": 100,
					"hz": "144hz"
				},
				{	
					"user": "iRaily",
					"link": "https://youtu.be/qXTFVx89sOg",
					"percent": 100,
					"hz": "144hz"
				},
				{	
					"user": "nayf",
					"link": "https://youtu.be/4F---w1ti6c",
					"percent": 100,
					"hz": "360hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/lMdKWPACHF4",
					"percent": 100,
					"hz": "360hz"
				},
				{
					"user": "EyeHurty",
					"link": "https://www.youtube.com/watch?v=65fq1emObZY&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "crumche",
					"link": "https://cdn.discordapp.com/attachments/737134935881809963/737135467493064704/shitty_balengu_vortex.mp4",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=lUW-AFgfpjc",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "HamburgerMan",
					"link": "https://www.youtube.com/watch?v=G88fvnpZRME",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=XshqPuyAGgg&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Tentacled",
					"link": "https://www.youtube.com/watch?v=72AFTCSpyJk",
					"percent": 67,
					"hz": "144hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/SoafUNvCswM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/Zms4kpID0i0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/hDGgiYqQkfc",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=H8WR_jg6GCw&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Slithium",
					"link": "https://youtu.be/eCGeqNP21T4",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "CavEmaN_mElviN",
					"link": "https://www.youtube.com/watch?v=Yguu9ELGXBA",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=tc0_i3AIzVE",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Ultraviolet",
					"link": "https://www.youtube.com/watch?v=iU5ZggqBjUI&feature=youtu.be",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/TLVHEzRfmp4",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Covieta",
					"link": "https://youtu.be/svyPIN6wM_E",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Emonadeo",
					"link": "https://www.youtube.com/watch?v=fXZWcpPlJzg",
					"percent": 100,
					"hz": "120hz"
				},
			],
			"name": "Shitty Balengu Vortex",
			"author": "LJosh",
			"more": "none",
			"id": 59558248,
			"pass": "0002",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=rWcLT30sVj0",
			"key": 9
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://youtu.be/cvpixmgb4mw",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/UvHv46sOzI4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "MiniShoey",
					"link": "https://www.youtube.com/watch?v=OBrc5hk4A8Y",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=P4Y_gwphI_o",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=zK9kLcbufNQ&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=CxEqBdkOk2w",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/t0zbmHj-DJ8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/x1XSEfknGvo",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/KAPId9vQGmk",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Poltergeist Reborn",
			"author": "LJosh",
			"more": "none",
			"id": 59560323,
			"pass": "0009",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=axeVcW9WATs",
			"key": 10
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=_VsX_49RE1w",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=lyXDe4fePRo",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "sandstormy",
					"link": "https://www.youtube.com/watch?v=db6l9E6ZPEY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Chojang",
					"link": "https://youtu.be/FXeIm0gI3ok",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "PriUsGD",
					"link": "https://youtu.be/FCDHwEHOgls",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/vSG9BVOndYk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/JpJJZcUo_qk",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/i08XJjvIv6A",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Matter",
					"link": "https://www.youtube.com/watch?v=WQpM8_IjQlQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/P1coLocKcRE",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Amedxx2y",
					"link": "https://youtu.be/7PsRypetCBw",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/SDR3N3dtQZM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/I3Dk48AwyLc",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Wunjo",
					"link": "https://www.youtube.com/watch?v=aNxMu8d4XX0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=hSV2erBIcdw",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/wXL-6LU0w4U",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=w6DGHI9S6Hk&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/GNuQqEwrBl4",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=vg_W3giAekw",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "TheRealYeeter",
					"link": "https://youtu.be/yrqrbRNwWjY",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/R2Q6MulvIMs",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Sunset Sandstorm",
			"author": "LJosh",
			"more": "none",
			"id": 59560341,
			"pass": "0007",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=3C4XngzGGlE",
			"key": 11
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "GDTeabag",
					"link": "https://www.youtube.com/watch?v=4P59t8EJLb0&t=",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=LXt7tDezbfE",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/EXpkCJAOVJg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/hHPWf1-waZo",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Surpl3x",
					"link": "https://youtu.be/7fks6q5VBQE",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "GDmeric",
					"link": "https://youtu.be/7PD1l8dMuUI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GrimPencil16",
					"link": "https://youtu.be/m7dyn6qeBmE",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Alphanetic",
					"link": " https://youtu.be/XPy30wsqEIk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=1AfhPJICnuwk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=rBz7CHbsnxo&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=re9PKJeof18",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=RWR2UhaXaww",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/699053634",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=5nTF8qMZz4o",
					"percent": 100,
					"hz": "288hz"
				},
			],
			"name": "Shitty Hatred",
			"author": "LJosh",
			"more": "none",
			"id": 59560360,
			"pass": "0008",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=FiJIwowWp1g",
			"key": 12
		},
		/*=================================================================================*/
		{
		        "vids": [
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=6l9yo8vdfvY",
					"percent": 80,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=_rP3WjgIo3Y",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/tGV5_z4XRx8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/jpPXesuRPtc",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=sgt4_lcrxEw",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "GDMeric",
					"link": "https://www.youtube.com/watch?v=r8dABwGrPyY&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/sp4LAVd8D2k",
					"percent": 100,
					"hz": "288hz"
				},
			],
			"name": "Shitty Catharsis",
			"author": "TheKate and more [MrDash]",
			"more": "Vlaash, AcropolisBoy, theRealKlaro, zLunatiX, MoVaVi",
			"id": 60457267,
			"pass": "032520",
			"percentToQualify": 52,
			"verificationVid": "https://www.youtube.com/watch?v=N9vQCwp01pM",
			"key": 13
		},
		/*=================================================================================*/
		{
			"vids": [
 				{
                                        "user": "Amedxx2y",
                                        "link": "https://youtu.be/PPQfZlvOvVw",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/GFQow4P97Hc",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "GDTeaBag",
					"link": "https://www.youtube.com/watch?v=ljPKJP7GSEM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/P5arS_icvgI",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=VL4JsbsSuek",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/unOGw2hWu5E",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/EWo8547nNMs",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/qrtHzMxhiuA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=z5T9VAjF_60",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/whv_hAob_hw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/698094594",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Blathers",
					"link": "https://youtu.be/cOzlr41GFZw",
					"percent": 94,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=EB8GFwf0lP8&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Renevant",
			"author": "Acropolisboy [LJosh]",
			"more": "none",
			"id": 58163785,
			"pass": "100006",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=RPDmLNJBpMc",
			"key": 14
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=iXO7jcRxb9Q",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/o2U25g6T7iw",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/zPaTlPPZXwA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Chojang",
					"link": "https://youtu.be/x3Q2xm525Dg",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=5l-o3QcJvPo",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "PriUsGD",
					"link": "https://youtu.be/Gl7w8A7jI3M",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Amedxx2y",
					"link": "https://youtu.be/MVEP-lEM6vk",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=p-Ek6R-MTtk",
					"percent": 81,
					"hz": "60hz"
				},
				{
					"user": "1qawsz",
					"link": "https://youtu.be/6FDMhSs6Obw",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/gh2YrHb4CfE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/R9_KmhU6yc0",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=E9IgH8dDXYQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Glommy Boy",
					"link": "https://youtu.be/LvY-jHBQyO4",
					"percent": 80,
					"hz": "Mobile"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/5USdJxTvaDk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=lRgdw3J0fV4&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
                        ],
			"name": "Shitty WOW",
			"author": "oSpace [LJosh]",
			"more": "none",
			"id": 56712681,
			"pass": "789123",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=xGBfvrRvIbU",
			"key": 15
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "iRaily",
					"link": "https://youtu.be/gw0esWl_xJs",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=MIVb4GDO8pI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=IiFqHmP1pa0&t=2s",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "GDTeaBag",
					"link": "https://youtu.be/1Y1T2UdSCEY?t=1478",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/iCZCxad-bc4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/U14IHvWUIGk",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/OLT0PTvPkSs",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "crumche",
					"link": "https://cdn.discordapp.com/attachments/457568615026393098/735507273497051216/shitty_tapwreck.mp4",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/IBTMOm4lOMk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/6uYGgp-cbm8",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Aassbll",
					"link": "https://youtu.be/TrGhuowgscE",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Moosh",
					"link": "https://www.youtube.com/watch?v=jX1JxxxwZiA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "saturn",
					"link": "https://www.youtube.com/watch?v=nfcT51SRiBU",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Veedio",
					"link": "https://youtu.be/5jYrlpX621s",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/ZESrQKrA5A8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Tonyearl",
					"link": "https://youtu.be/NDKHBemzxPw",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=gvxNkRWz5nc&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "lvcxs",
					"link": "https://youtu.be/T6XR6opwr8o",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/VwSMXf952Qw",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/XjopnOZ_XbM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Jjustalex",
					"link": "https://youtu.be/O6A8snmk-48",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Mark Napkin",
					"link": "https://www.youtube.com/watch?v=9b5ZY0Spu9k",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=5uRU0zVCwUc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/4k4D2tjAa0w",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/PTl6kNRqPp0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=Ai2zBdu4Z1Y",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=fpXJng6_PLI",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=GsgnAnEJ3hs&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Nevise",
					"link": "https://youtu.be/nC3OjeK8QO4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Arcturus",
					"link": "https://youtu.be/Eamt3npOVrM",
					"percent": 100,
					"hz": "300hz"
				},
			],
			"name": "Shitty Tapwreck",
			"author": "AcropolisBoy [Sleynt]",
			"more": "none",
			"id": 58649849,
			"pass": "666666",
			"percentToQualify": 50,
			"verificationVid": "https://www.youtube.com/watch?v=Qthrvca6JAs",
			"key": 16
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=bOHhdia7wSc",
					"percent": 100,
					"hz": "270hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=Au-pIp2z230",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/cMXv_CyUiVQ",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "aurora",
					"link": "https://youtu.be/JAkdV8huJxw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/0qmVV9H_N9U",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Moosh",
					"link": "https://www.youtube.com/watch?v=_fYQFh69Nz4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/UrzhzAV2qiQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/1J1PAjvwHuw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=gsp5iLJ4AIc",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/g_b4V-UtMFM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "lvcxs",
					"link": "https://youtu.be/MgvGLvj2sSw",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=HXH-KC-yQ1M&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=DP8b3m_melQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Praerius",
					"link": "https://www.youtube.com/watch?v=ZjSJfrbi1G8&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Amza",
					"link": "https://youtu.be/xkPXf5gdbEg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Tai0",
					"link": "https://youtu.be/uvAt-sNiPqg",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Covieta",
					"link": "https://youtu.be/iq90D4QAcAg",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty WcropoliX",
			"author": "LJosh",
			"more": "none",
			"id": 59558228,
			"pass": "000002",
			"percentToQualify": 57,
			"verificationVid": "https://youtu.be/708VHDpYJGo",
			"key": 17
		},
		/*=================================================================================*/
		{
			"vids": [
				{
                                       "user": "Amedxx2y",
                                       "link": "https://youtu.be/AlTh7-Cpsnc",
                                       "percent": 100,
                                       "hz": "mobile"
                                },
				{
				        "user": "Whiliams8080",
					"link": "https://www.youtube.com/watch?v=HMU_TVA7U14",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=gSWLlMJCBNg",
					"percent": 90,
					"hz": "Mobile"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=LKAnXjh9Lpg",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=b2Samlnkxm4",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://youtu.be/oa8bGWtZ7yI",
					"percent": 78,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/lAkU4BWWto8",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=OiQlGRgGNnM",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "Kr_Flame",
					"link": "https://youtu.be/cRbLlrEjdg4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "justiceguy",
					"link": "https://youtu.be/wJSFF9zVyjg",
					"percent": 74,
					"hz": "60hz"
				},
				{
					"user": "1qawsz",
					"link": "https://youtu.be/evopDhTXEfs",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/ii0b9tVP5vw",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Cyns",
					"link": "https://youtu.be/tNGvpmKwgpM",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/krZroYFKbdE",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/O3ZDoxS2a9Q",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Deados35",
					"link": "https://youtu.be/kor47PYUTf0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=5nOE3z8O7sk&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/XxuCvKiUrbM",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Magma",
					"link": "https://www.youtube.com/watch?v=dbg0nV_sN9c",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/9oq4wCooLN8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=fFTjkop5FkA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=PDwlExBdL2E",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Megum",
					"link": "https://www.youtube.com/watch?v=QujrmwBzIjk",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "lvcxs",
					"link": "https://youtu.be/WANAFyq8vNc",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Blast",
					"link": "https://youtu.be/7rMQK6kjOWY",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Praerius",
					"link": "https://www.youtube.com/watch?v=Zf0h9V5VYCA&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/700989857",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/sR6bv2NUHgU",
					"percent": 100,
					"hz": "120hz"
				},
			],
			"name": "Shitty Missing Benefits",
			"author": "Keleru",
			"more": "none",
			"id": 52494510,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=Iu08clOYt8I",
			"key": 18
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=53Cc3LU2LNM&feature=youtu.be",
					"percent": 100,
					"hz": "75hz"
				},
				{
                                        "user": "Amedxx2y",
                                        "link": "https://youtu.be/xLo_AuI9kYQ",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
					"user": "zMarc",
					"link": "https://youtu.be/S68LjA4LTwI`",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=ywbmmsfvP3g",
					"percent": 100,
					"hz": "150hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/8YgX0L65fb8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/NiF973ZPn28",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Veedio",
					"link": "https://www.youtube.com/watch?v=H4uBxxSu7sw&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/sAzeOcSklpw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/PZ494rurvbk",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Step To Hell",
			"author": "oSpace",
			"more": "none",
			"id": 54868104,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=f8HQ1T1HmXs",
			"key": 19
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=I8Xo3JL8fjs",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=BxaadTZkpS8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Alphanetic",
					"link": "https://youtu.be/fix5Sx8p_5U",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/-ytR49MZoLM",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/9hPk3mm7q7E",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/6nAmsWgvgsY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/ZLPE5qVv2tU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/umtLxUfo7mQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/IDV33iI2Avs",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/L_w5YJ7chLo",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "HamburgerMan",
					"link": "https://www.youtube.com/watch?v=RcVXPE7oVPU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Blathers",
					"link": "https://youtu.be/4c8XkSsqXSE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/3ENFoJxDyBM",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Arcturus",
					"link": "https://youtu.be/ddiBa8gjbyw",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=QdeGziaS_Vg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=-Mfm86KH5Wc&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "CavEmaN_mElviN",
					"link": "https://www.youtube.com/watch?v=BEKefkip1kA&list=PLAHT5vTrU-yiL3XyTFLt8XbRvYqQOXGIj&index=2",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=MAHF53u3U5s&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TH54",
					"link": "https://youtu.be/PpVWSe6NhJY",
					"percent": 59,
					"hz": "240hz"
				},
				{
					"user": "xBlur",
					"link": "https://www.youtube.com/watch?v=R2Khy_1Qc24&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Migel",
					"link": "https://youtu.be/QNsxM5ecCq0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Slithium",
					"link": "https://youtu.be/yyuIWw8aYsc",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "FrostBurn",
					"link": "https://youtu.be/rkRr0QWI1t0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/699006327",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Renar333",
					"link": "https://www.youtube.com/watch?v=q8R7rzaLfPc&feature=youtu.be",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "HowlingBolt",
					"link": "https://www.youtube.com/watch?v=xVHbY2G8nl4&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Covieta",
					"link": "https://youtu.be/kY1zBJouJP0",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Arctic Lights",
			"author": "Serpyy and XanPlayzGamez [Serpyy]",
			"more": "none",
			"id": 60253685,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=I8Xo3JL8fjs",
			"key": 20
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/cNRatJWzyYE",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=c7wKRhMtrUI&t=4s",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=Df_u7fcMdto&list=PL5lAe2NjqiU4rWNSVvBCt_dWPG5ScW3dg&index=39",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Batle",
					"link": "https://youtu.be/SPco9V4KpPw",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "TH54",
					"link": "https://youtu.be/8CKd0OxsWb8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/fPkgS8HrbGM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/8G2BklNDD6Y",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/A-nV05xEjRM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/C4wJ3JIvvTk",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Zettabyte",
			"author": "Serpyy",
			"more": "none",
			"id": 56768542,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=2Mkex3RGOnQ",
			"key": 21
		},
		/*=================================================================================*/
		{
			"vids": [
                                {
                                         "user": "Amedxx2y",
                                         "link": "https://youtu.be/HUmYrV8rroM",
                                         "percent": 100,
                                         "hz": "Mobile"
                                },
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=q-Vfoemsmas",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=UlJ9KGc3JF8&t=15s",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=nWwv_IZztGo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://youtu.be/d14djfj-5Lo",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/kbY8P_mROcs",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/2WninFz4FeA",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/xcXCRmfB6tQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Arcturus",
					"link": "https://youtu.be/3wSAdd7Ioo8",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=TvuT3rbtmMg&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Megum",
					"link": "https://www.youtube.com/watch?v=CEO9I6Xr7EE",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Renar333",
					"link": "https://www.youtube.com/watch?v=QUIrHaCg6u0&feature=youtu.be",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "GDMeric",
					"link": "https://www.youtube.com/watch?v=xWxax4mV7Ao&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Eternal Moment",
			"author": "Miini03",
			"more": "none",
			"id": 59680007,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=CEO9I6Xr7EE",
			"key": 22
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=SwZk3N-xCko",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/e6X7phy3yuY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "1qawsz",
					"link": "https://youtu.be/bV1TdXVaxl0",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/3ABpRnkruoM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/_oH6tEu5a_8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/f4VMDbvSmqU",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Innards",
			"author": "Keleru",
			"more": "none",
			"id": 49731309,
			"pass": "000005",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=yW9oNZ07yC8",
			"key": 23
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Vink",
					"link": "https://www.youtube.com/watch?v=1jUbZWVqn-Q",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/mW8g2QNZllk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=VVrOqsbs-2U",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Aassbll",
					"link": "https://youtu.be/iYimiJf5eZQ",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://www.youtube.com/watch?v=gifUGPpys-8&feature=youtu.be",
					"percent": 64,
					"hz": "60hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=OBH8lMkFbsY",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Bluuper",
					"link": "https://www.youtube.com/watch?v=6CBBWl6kpqI",
					"percent": 100,
					"hz": "144hz"
				},
				{
                                        "user": "nayf",
                                        "link": "https://youtu.be/5DNaZzeu4KU",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "EyeHurty",
                                        "link": "https://www.youtube.com/watch?v=mKHWyOMB4n8&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "288hz"
                                },
				{
                                        "user": "GrimPencil16",
                                        "link": "https://youtu.be/mtGu0B-zb3k",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
                                        "user": "Alphanetic",
                                        "link": "https://youtu.be/F6mnTmLrhfA",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
                                        "user": "WowoGD",
                                        "link": "https://www.youtube.com/watch?v=T7f-idWGhL8&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "GDMeric",
                                        "link": "https://youtu.be/4XAHRnQckdE",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
                                        "user": "Creatormichaelr",
                                        "link": "https://youtu.be/pfMwc4BSbW4",
                                        "percent": 100,
                                        "hz": "300hz"
                                },
				{
                                        "user": "piesy",
                                        "link": "https://youtu.be/EbjCM5E5vrQ",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
					"user": "TH54",
                                        "link": "https://www.youtube.com/watch?v=Ss2l2eqCJ1A",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "Conical",
                                        "link": "https://youtu.be/LDy1Yaho4OI",
                                        "percent": 100,
                                        "hz": "180hz"
				},
				{
					"user": "Spacethug",
                                        "link": "https://youtu.be/zjDLDytfQ00",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "lvcxs",
                                        "link": "https://www.youtube.com/watch?v=TK6OfZHYWGI&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "Th13teen",
                                        "link": "https://www.youtube.com/watch?v=3piPIETFRiE&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "TFIBB",
                                        "link": "https://www.youtube.com/watch?v=JFopyaIUxZE",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "Arcturus",
                                        "link": "https://youtu.be/vand23Pya64",
                                        "percent": 100,
                                        "hz": "300hz"
				},
				{
					"user": "Dist3nd",
                                        "link": "https://youtu.be/pk86bsG0RFk",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "CavEmaN_mElviN",
                                        "link": "https://www.youtube.com/watch?v=rYtXyyB2jCo",
                                        "percent": 100,
                                        "hz": "300hz"
				},
				{
					"user": "Zephal",
                                        "link": "https://www.youtube.com/watch?v=wGwqssb_wJY&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "288hz"
				},
				{
					"user": "jToniX",
                                        "link": "https://youtu.be/WzWyNAP6G0E",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=9lR8LAlMWSk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Slithium",
					"link": "https://youtu.be/PxkjyQkYYPs",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Migel",
					"link": "https://youtu.be/B3xpRprROWU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Unecycle",
					"link": "https://youtu.be/mNaO6KgKHJI",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/gsfFuhmxiXU",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "KriSsi",
					"link": "https://www.youtube.com/watch?v=BxFdXLB2-_M&feature=youtu.be",
					"percent": 100,
				        "hz": "240hz"
				},
				{
					"user": "Covieta",
					"link": "https://youtu.be/0eDvOMhWg0w",
					"percent": 100,
				        "hz": "144hz"
				},
				{
					"user": "Lupe1204",
					"link": "https://youtu.be/MLEE78gUFVM",
					"percent": 100,
				        "hz": "Mobile"
				},
			],
			"name": "Shitty Aquatic Auroras",
			"author": "Aassbll [PotatoManPlays]",
			"more": "none",
			"id": 60828884,
			"pass": "Free to copy",
			"percentToQualify": 58,
			"verificationVid": "https://www.youtube.com/watch?v=gx-NqXHlGoA",
			"key": 24
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=Pn_OeOB7-u8",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/u4ZAb6xUbT0",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/NuyfbfPPB-E",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Aassbll",
					"link": "https://youtu.be/G3EkIFzAovI",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/cSbOj55gKqc",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Praerius",
					"link": "https://www.youtube.com/watch?v=y5JyQRBqC0g",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=w_vIMh9eRzk&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Ayanakodji",
					"link": "https://youtu.be/EXF7oc6dH7k",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/XvTcfXsNOFw",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/AkIpAN_F-XA",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/Ez_HHQUCjrE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "YellowDoopAlt",
					"link": "https://omlet.gg/v/ahazLlQI_oz5toS_J",
					"percent": 100,
					"hz": "Mobile"
				},
			],
			"name": "Shitty Wasureta",
			"author": "AcropolisBoy",
			"more": "none",
			"id": 62015030,
			"pass": "Free to copy",
			"percentToQualify": 50,
			"verificationVid": "https://www.youtube.com/watch?v=Wc_Jj3oWXL0",
			"key": 25
		},
		/*=================================================================================*/
                {
			"vids": [
				{
					"user": "GDTeaBag",
					"link": "https://youtu.be/1Y1T2UdSCEY?t=9",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "sandstormy",
					"link": "https://www.youtube.com/watch?v=JDN8z5TZEK4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=R0s0VKFhIn0",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/zwC3CZoTm8M",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "DJJDK",
					"link": "https://youtu.be/lKz0a2JWDjU",
					"percent": 67,
					"hz": "165hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=BxaadTZkpS8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/vVddM40VLWY",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/rLnAEHHbtec",
					"percent": 100,
					"hz": "360hz"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/Pm5LiYjmaKk",
					"percent": 100,
					"hz": "360hz"
				},
				{
                                        "user": "GDMeric",
                                        "link": "https://www.youtube.com/watch?v=J82TfOgxcPI",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
                                        "user": "piesy",
                                        "link": "https://youtu.be/L_Eg3UEsv70",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "HamburgerMan",
                                        "link": "https://www.youtube.com/watch?v=I8pAS30Dvh0&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
					"user": "MythicalTG",
					"link": "https://youtu.be/XCZRGwchXmg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/U2OMle-wyDE",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Wyaaronpc",
					"link": "https://youtu.be/w_PzMka7VeA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Hixobit",
					"link": "https://www.youtube.com/watch?v=OV2fHOOrEIA",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=mFVy4uV52yU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Spacethug",
					"link": "https://youtu.be/qEFkhoMOQOY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=kyhkxFzTFUw&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "CavEmaN_mElviN",
					"link": "https://www.youtube.com/watch?v=yQkJCBnc3ss",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "TheRealYeeter",
					"link": "https://youtu.be/BM7YAoYvw4w",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/O4m1LHGFNbQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/697109849",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "JoeBruhGD",
					"link": "https://www.youtube.com/watch?v=3VHbY5wsYmA&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
			],
			"name": "Shitty Sonic Wave",
			"author": "Acropolisboy [timckic]",
			"more": "none",
			"id": 55367155,
			"pass": "001006",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=dnjnt9rI_qc",
			"key": 26
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/XzxjsZlUU84",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=L736VUCKtVU",
					"percent": 100,
					"hz": "144hz"
			        },
				{
					"user": "iRaily",
					"link": "https://youtu.be/4rlEqG-Gb3M",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=BxaadTZkpS8",
					"percent": 100,
					"hz": "240hz"
				},
				{
                                        "user": "nayf",
                                        "link": "https://youtu.be/fOKTa2D6ruU",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "Asdner",
                                        "link": "https://youtu.be/0ci9fHpSCRw",
                                        "percent": 63,
                                        "hz": "69hz"
                                },
				{
                                        "user": "GDMeric",
                                        "link": "https://youtu.be/8OTlECSBRgU",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
					"user": "piesy",
					"link": "https://youtu.be/BHmPa5mS3vw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/D3wrCInCRpQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Dist3nd",
					"link": "https://youtu.be/YKgGhQnGFg0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/4uzus2QK3i4",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/n4ln9S4ZI-4",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "lvcxs",
					"link": "https://youtu.be/djw8L1n5iD8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/yQ9W_1zBCes",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=YUa7F_yYRhA&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "CavEmaN_mElviN",
					"link": "https://youtu.be/45QUkLMS68I",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/4ciD5oBhGYQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Blathers",
					"link": "https://youtu.be/FiKIpuPcZ-g",
					"percent": 69,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=6_tVPDOI5HA&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
                        ],
			"name": "Shitty Hyper Paracosm",
			"author": "DigestedCitrus [Deimoz]",
			"more": "none",
			"id": 62106120,
			"pass": "Free to copy",
			"percentToQualify": 52,
			"verificationVid": "https://youtu.be/XzxjsZlUU84",
			"key": 27
		},
		/*=================================================================================*/
		{
			"vids": [
				{
                                        "user": "Amedxx2y",
                                        "link": "https://youtu.be/4btfmkrYRFQ",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
					"user": "Aassbll",
					"link": "https://youtu.be/mO59qZitpGA",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/20e3I-zjmLE",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=oXiRhT35zFU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDTeaBag",
					"link": "https://youtu.be/1Y1T2UdSCEY?t=713",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/nuA0hfze0xU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Surpl3x",
					"link": "https://youtu.be/mgl-tn3xPoE",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/2Al4j_4sxJY",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/UnDTeJSKe24",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=iEnZ6Pt_JRA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/bTixnqONZw8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/jPHn2lejeqg",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=lwinR_RBLNE&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/5dccidFJ7JI",
					"percent": 100,
				        "hz": "144hz"
				},
			],
			"name": "Shitty Tartarus",
			"author": "AcropolisBoy [Darkys]",
			"more": "none",
			"id": 59699245,
			"pass": "606606",
			"percentToQualify": 53,
			"verificationVid": "https://www.youtube.com/watch?v=YXi4n8byylM",
			"key": 28
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=l0JOnlifnsg",
					"percent": 100,
					"hz": "240hz"
				},
				{
                                        "user": "Amedxx2y",
                                        "link": "https://youtu.be/t8yDWgktw20",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/UOK0tKqsxKU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=CqAMnnz5Nbw",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Chojang",
					"link": "https://youtu.be/2XuPYTN03dk",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Trollomggamer",
					"link": "https://youtu.be/q4s5-eDpitQ",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/8VWDHVUaSs0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/8MZCWRAeCFg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Praerius",
					"link": "https://www.youtube.com/watch?v=gqFRFgnaXlc&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Renar333",
					"link": "https://www.youtube.com/watch?v=I8s_Z5xhRU4&feature=youtu.be",
					"percent": 100,
					"hz": "120hz"
				},
			],
			"name": "Shitty Deimos",
			"author": "oSpace",
			"more": "none",
			"id": 57271231,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=F7BO5D2b6Mo",
			"key": 29
		},
		/*=================================================================================*/
		{
			"vids": [
				{
                                        "user": "Amedxx2y",
                                        "link": "https://youtu.be/IZRMNG4PRxE",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
					"user": "rVlaash",
					"link": "https://youtu.be/OqxLgOTQ9cs",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Whiliams8080",
					"link": "https://www.youtube.com/watch?v=0YAWYj6Y7Ig",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://youtu.be/BwZY9GqGgTo",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=xmgnwKF-pFk",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=RwHeNSH-qvk",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/rFuwwGL6CK8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/DQd4xvGYXYw",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=8XYhcvWLFEg&list=PL5lAe2NjqiU4rWNSVvBCt_dWPG5ScW3dg&index=40",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "rMinelo",
					"link": "https://youtu.be/FY_9GC9jv8s?t=4013",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "justiceguy",
					"link": "https://www.youtube.com/watch?v=aulcw3aFh3A",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/PmnllkqKcIc",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/HZlZyd0cF_M",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/wWjc2fh1qjM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/OnTAP5fqjFc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Zshadoweye",
					"link": "https://www.youtube.com/watch?v=VMwNvh2XNIY&t=8s",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Hulunn",
					"link": "https://www.youtube.com/watch?v=IEmv5ZMteNg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/wayGeWhEum0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Jah",
					"link": "hhttps://www.youtube.com/watch?v=DseNofoMZ7A&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Megum",
					"link": "https://www.youtube.com/watch?v=dF83WTlXt5Q",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/eGsKy8bqmKE",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "FrostBurn",
					"link": "https://youtu.be/prtHBSPAjCk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Wadur",
					"link": "https://www.youtube.com/watch?v=GHDQ1g5TFRg&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "spacethug",
					"link": "https://youtu.be/ItZCBy0yRG8",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Ragnarok",
			"author": "oSpace",
			"more": "none",
			"id": 55909152,
			"pass": "343707",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=GvfSqt8ZBbY",
			"key": 30
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=Z4WuP46fJtc",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/nNgAcfLkUzM",
					"percent": 100,
					"hz": "120hz"
				},
			],
			"name": "Shitty Delebit Oblivio",
			"author": "HdLink13 [rVlaash]",
			"more": "none",
			"id": 62077742,
			"pass": "Free to copy",
			"percentToQualify": 63,
			"verificationVid": "https://www.youtube.com/watch?v=09oeh0nUJEQ",
			"key": 31
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=7txLvxG1y5E&lc=UgxX_OXAgeBbkE2VqbJ4AaABAg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=4sJ_70nnPOc&feature=youtu.be",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=PSAjB5fou68&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=rrk0G7LX2-w",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "sandstormy",
					"link": "https://www.youtube.com/watch?v=fMcQQDYRqhk&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=BxaadTZkpS8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=PbY_eY-pDRE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/c3M4Udf8ul4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/-CAKv6rGcIE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/b5HMyCGA_Dg",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "lvcxs",
					"link": "https://www.youtube.com/watch?v=WI_sSmcA4fU&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Macabre",
			"author": "oSpace and more [Serpyy]",
			"more": "GDStarStorm, Serpyy",
			"id": 57337559,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=72THO_lErmg",
			"key": 32
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=_2KzC-qCRnY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/_hja-CmLOpE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/E1lMglgi8W8",
					"percent": 100,
					"hz": "120hz"
				},
			],
			"name": "Shitty UltraSans",
			"author": "GDStarStorm and more [LJosh]",
			"more": "LJosh, SoyNadie",
			"id": 57002669,
			"pass": "259358",
			"percentToQualify": 56,
			"verificationVid": "https://www.youtube.com/watch?v=_2KzC-qCRnY",
			"key": 33
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=2vUjW5Kraag",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "amedxx2y",
					"link": "https://youtu.be/ydmKp0WrkiM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=tymWxxumiVk",
					"percent": 100,
					"hz": "200hz"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://www.youtube.com/watch?v=3myqjTCiRcw",
					"percent": 65,
					"hz": "240hz"
				},
				{
					"user": "ZekronGD",
					"link": "https://youtu.be/1MZGHzTYLzE",
					"percent": 77,
					"hz": "Mobile"
				},
				{
					"user": "NanCho",
					"link": "https://youtu.be/z53uUl25Zr0",
					"percent": 65,
					"hz": "240hz"
				},
				{
					"user": "iRaily",
					"link": "https://www.youtube.com/watch?v=dZcFc7FLkxk&t=11s",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/TCuYG7pIs08",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/j8nBgezuIgw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=9KVEx5misGY&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/yfycoIVPQd4",
					"percent": 100,
					"hz": "120hz"
				},
			],
			"name": "Shitty Calculator Core",
			"author": "oSpace and more [oSpace]",
			"more": "AcropolisBoy, Megum, TheKate, ItzShuvon, MiiNi03, HeizenSS, ImColdBlast, AlexTheGS33",
			"id": 62034895,
			"pass": "Free to copy",
			"percentToQualify": 52,
			"verificationVid": "https://www.youtube.com/watch?v=Zs3wbxEiWy0",
			"key": 34
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "AcropolisBoy",
					"link": "https://youtu.be/iQPeK6Zgqy8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Whiliams8080",
					"link": "https://www.youtube.com/watch?v=MjUlvTt31Wc",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/Fw4ta09GY10",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "PriUsGD",
					"link": "https://youtu.be/iBAcfSHUMjE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=gkvLFHDEZk4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "1qawsz",
					"link": "https://youtu.be/VUkjnS2r-zw",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Kr_Flame",
					"link": "https://youtu.be/lcjr1z5Lawk",
					"percent": 71,
					"hz": "240hz"
				},
				{
					"user": "HideriGH",
					"link": "https://youtu.be/623XZf-x6Us",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=Mt_h83MOnPk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=YdJwRqbuxMU&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Elevens",
					"link": "https://www.youtube.com/watch?v=CzQZqwvyqmw",
					"percent": 59,
					"hz": "60hz"
				},
				{
					"user": "YellowDoopAlt",
					"link": "https://youtu.be/hVN-a0qiR40",
					"percent": 100,
					"hz": "Mobile"
				},
			],
			"name": "Shitty Orochi",
			"author": "Keleru",
			"more": "none",
			"id": 49907278,
			"pass": "159874",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=n-1BTK0cIvA",
			"key": 35
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=c8lLnBVJg1g&list=PL5lAe2NjqiU4rWNSVvBCt_dWPG5ScW3dg&index=26",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "rVlaash",
					"link": "https://youtu.be/WblsmOFsrlc",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://youtu.be/6fwIUP1Brgg",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "EarthyYakoob",
					"link": "https://www.youtube.com/watch?v=kruwGB2MCN4",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/-zCM2CjnsSM",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=iWD-QWJSBi4&t=11s",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=jNNCzs8nks0",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/tOElkolP8Cg",
					"percent": 100,
					"hz": "144hz"

				},
				{
					"user": "amedxx2y",
					"link": "https://youtu.be/jKpRSrVnlyc",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Chojang",
					"link": "https://youtu.be/iZ2bcBmMsqo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/mQP7IZiRU1Y",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Gloomy boy",
					"link": "https://youtu.be/AZduHWdn8PE",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Vaxer",
					"link": "https://www.youtube.com/watch?v=uf1UUyeEh6c",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Trollomggamer",
					"link": "https://youtu.be/cqO8ChgleLw",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/jbQzyqCSFpM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "iRaily",
					"link": "https://www.youtube.com/watch?v=1nLhKkpWy4s",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "justiceguy",
					"link": "https://youtu.be/jUDCR2WixQk",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "GdWaaab",
					"link": "https://youtu.be/J-Ihm-8exJs",
					"percent": 69,
					"hz": "Mobile"
				},
				{
					"user": "Frigus",
					"link": "https://youtu.be/86-1ZKdPpOQ",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/Cmi8AesBNwQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/ps9vpsVhetg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/CjwcxM64fRI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/dVmG_SEWtoc",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "ShDwGhost",
					"link": "https://youtu.be/0lsHXrnSHGs",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Veedio",
					"link": "https://www.youtube.com/watch?v=twyt4L9GkRM&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Hulunn",
					"link": "https://www.youtube.com/watch?v=gcsgwp6bua0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "rslashknight",
					"link": "https://youtu.be/3eM0tTLRZAA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "ShadowNinja441",
					"link": "https://youtu.be/aARZjbwEuEM",
					"percent": 78,
					"hz": "Mobile"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=eXPMR6z7HEY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Tai0",
					"link": "https://youtu.be/sVRCqpxhD-Y",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/SYvmboMYy5c",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "xBlur",
					"link": "https://www.youtube.com/watch?v=_MfOwMB4zZo",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=eC76q2m48SY&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=RLCCrlAFI1A&t=",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "hren228",
					"link": "https://www.youtube.com/watch?v=6RjEi0jZMoY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "nIleum",
					"link": "https://youtu.be/sHHVUoTXwgQ",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "MacJubber",
					"link": "https://youtu.be/TaBU6nLbOKc",
					"percent": 100,
					"hz": "300hz"
				},
			],
			"name": "Shitty Cognition",
			"author": "oSpace",
			"more": "none",
			"id": 57632273,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=tOElkolP8Cg",
			"key": 36
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=LDxpIyyYZFg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/JbCPOMj7hC4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Matter",
					"link": "https://www.youtube.com/watch?v=pmI1gKRd2dQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Nevise",
					"link": "https://www.youtube.com/watch?v=zgzIIyRjhF8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/gVUmKSH8VOs",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "FrostBurn",
					"link": "https://youtu.be/bW7xKUbCLLE",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Cosmorush 21",
			"author": "AcropolisBoy and Whiliams8080 [Bartoldo]",
			"more": "none",
			"id": 62509657,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=qmVqQqkM9wQ",
			"key": 37
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=tOI-iyJA7D0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "rVlaash",
					"link": "https://youtu.be/oMd3CqfBhvs",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=OLtHn2KoHzM",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "rMinelo",
					"link": "https://youtu.be/JxW4bYlV6l8",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=_Ksd6sKlD4g&t=461s",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "XoaOfficial",
					"link": "https://www.twitch.tv/videos/642942421",
					"percent": 95,
					"hz": "60hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/tAiyDE-EZbk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "amedxx2y",
					"link": "https://youtu.be/wMW4CCWRAr4",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "HdLink13",
					"link": "https://youtu.be/t3pwiVt0fUA",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Chojang",
					"link": "https://youtu.be/zcwYCtLJd-0",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "PriUsGD",
					"link": "https://youtu.be/I5PTyfyFrEs",
					"percent": 100,
					"hz": "144"
				},
				{
					"user": "Gloomy boy",
					"link": "https://youtu.be/smnAlACg8-Q",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Vaxer",
					"link": "https://www.youtube.com/watch?v=yZPkddZYCdk&t=3s",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "hello2578",
					"link": "https://m.youtube.com/watch?v=B1LpZRaNzFA",
					"percent": 72,
					"hz": "Mobile"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/K1DCmMw8oGc",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "WhiteTeeth",
					"link": "https://youtu.be/eNavw1w0gaY",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "FallenAresse",
					"link": "https://www.youtube.com/watch?v=pm1Bd32ksnA&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Veedio",
					"link": "https://www.youtube.com/watch?v=YC1-HycNC_0&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "ShDwGhost",
					"link": "https://youtu.be/Q3hqsKVJkKk",
					"percent": 92,
					"hz": "60hz"
				},
				{
					"user": "Acute",
					"link": "https://www.youtube.com/watch?v=YA7odpGibVE",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Batle",
					"link": "https://youtu.be/1mC7EOdzT9c",
					"percent": 100,
					"hz": "Mobile"
				},
			],
			"name": "Shitty Belloq",
			"author": "oSpace and more [oSpace]",
			"more": "Megum, ItzShuvon, MiiNi03, GDStarStorm",
			"id": 58294454,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=EvcFxAEED6g",
			"key": 38
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=sMCRm04pkq4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=MYiZJB_ElGc",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Retitled",
			"author": "Soda",
			"more": "none",
			"id": 61805507,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=nrDrncLXevE",
			"key": 39
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=mDie98ouoPM&t=3s",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Amedxx2y",
                                        "link": "https://youtu.be/dOTO17afdcI",
					"percent": 100,
                                        "hz": "Mobile" 
				},
				{
                                        "user": "rVlaash",
					"link": "https://youtu.be/VAkWqdvPNvk",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Whiliams8080",
					"link": "https://youtu.be/jYIA2lWhvOc",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/NE6ha-VMgzk",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/DZCV-yl5HRU",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "HdLink13",
					"link": "https://youtu.be/wJ_SVo8RKz4",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "PriUsGD",
					"link": "https://youtu.be/wJ_SVo8RKz4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GdWaaab",
					"link": "https://youtu.be/WAzd0hI3_do",
					"percent": 96,
					"hz": "Mobile"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/yJsM1GmExs4",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=mmWJmuCcOsk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/kHpeq5nFcYQ",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Dist3nd",
					"link": "https://www.youtube.com/watch?v=Qx3XXoJFtmU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "ThanosPig",
					"link": "https://youtu.be/GhPmmwKvf-I",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/Cmchpi-G56o",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "HamburgerMan",
					"link": "https://www.youtube.com/watch?v=zBIPHVBNoPg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/0Tlr2x16pEQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Pipzzzzzzz",
					"link": "https://youtu.be/ZURK-r4pVLs",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Ultraviolet",
					"link": "https://youtu.be/_MIZqMPpFRE",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://www.youtube.com/watch?v=Cg5CNYkHuPw&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/sQlYpdapjdk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "IIEliteRainII",
					"link": "https://youtu.be/D-uxwY3oCOA",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "avrg",
					"link": "https://youtu.be/vzLRuoeqySQ",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "DerpOverlord",
					"link": "https://youtu.be/1DEJSpjOvnU",
					"percent": 100,
					"hz": "Mobile"
				},
			],
			"name": "Shitty Awakening Horus",
			"author": "oSpace and Megum [oSpace]",
			"more": "none",
			"id": 54447236,
			"pass": "090319",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=irwPkK6x9Mg",
			"key": 40
		},
		/*=================================================================================*/
		{
			"vids": [
				{
                                        "user": "Fhyron06",
                                        "link": "https://www.youtube.com/watch?v=vvMFZnLM2Hk",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
					"user": "zMarc",
					"link": "https://youtu.be/jAswegucN80",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Pinball Panic",
			"author": "HdLink13 [GDTeaBag]",
			"more": "none",
			"id": 62581697,
			"pass": "Free to copy",
			"percentToQualify": 50,
			"verificationVid": "https://www.youtube.com/watch?v=nwef7j6lSc0",
			"key": 41
		},
		/*=================================================================================*/
		{
			"vids": [
				{
				 	"user": "Fhyron06",
                                        "link": "https://www.youtube.com/watch?v=Yj_b4n8fvXY",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
				 	"user": "piesy",
                                        "link": "https://youtu.be/lGqt9HLaV0c",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=9lR8LAlMWSk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "zMarc",
					"link": "https://www.youtube.com/watch?v=tEWbtRTkpL4&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Low Death",
			"author": "AcropolisBoy [GDTeaBag]",
			"more": "none",
			"id": 54841903,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=1Y1T2UdSCEY&t=2425s",
			"key": 42
		},
		/*=================================================================================*/
		{
			"vids": [
				{
                                        "user": "Amedxx2y",
                                        "link": "https://youtu.be/MazleInGC7Y",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
					"user": "Fhyron06",
                                        "link": "https://www.youtube.com/watch?v=w-O0aLYvGhA",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "zMarc",
                                        "link": "https://youtu.be/LjYzMaXK6JI",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "Th13teen",
                                        "link": "https://www.youtube.com/watch?v=FZUL4CMxHpw&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/fmpZB_BfaO0",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Matilda The Machine",
			"author": "XanPlayzGamez and Serpyy [XanPlayzGamez]",
			"more": "none",
			"id": 57906787,
			"pass": "563562",
			"percentToQualify": 57,
			"verificationVid": "https://youtu.be/szhP_KYmeaQ",
			"key": 43
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "rVlaash",
					"link": "https://youtu.be/3VJ_VMdexug",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Shadowbolts",
					"link": "https://youtu.be/UPc5PmD3I0c",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=RBtuAeTNXMY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=kexZD6JJck0&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
	                ],
			"name": "Shitty Ancestral Calamity",
			"author": "oSpace and more [oSpace]",
			"more": "ItzKot, SoyNadie, Megum, Kevinacho18, MiiNi03, ShadowNinja441",
			"id": 55302658,
			"pass": "300419",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=maJcSIR-SLU",
			"key": 44
		},
		/*=================================================================================*/
		{
		        "vids": [
				{
					"user": "Vink",
					"link": "https://youtu.be/0H2GPqIJXCs",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "MitSuS",
					"link": "https://www.youtube.com/watch?v=FlJ2IslNtFM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/pA4EF1Yvs8E",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/FIGIkVwuH8g",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=Pk5FkBDoT3M",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/97I9pUDFtF0",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Alphanetic",
					"link": " https://youtu.be/wnmJg_hum5M ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/0v97TT5RmVw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/Uaynj4_HJWw",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/ED7XoSUU6HU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Matter",
					"link": "https://www.youtube.com/watch?v=krMFmv6lF5Y",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "lvcxs",
					"link": "https://youtu.be/_Qq1ldRT5D8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "jToniX",
					"link": "https://youtu.be/l3JptjK_tyU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "FrostBurn",
					"link": "https://youtu.be/Eb-_hF5_dss",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Slithium",
					"link": "https://youtu.be/35JNSlSB5Sg",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=HtrSRnugYdI&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "nileum",
					"link": "https://www.youtube.com/watch?v=XDz4zmJziwY",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Creatormichealr",
					"link": "https://www.youtube.com/watch?v=7re163PqgSs&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/VebLdLLP7IU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/NlNmW26C8sU",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Bluuper",
					"link": "https://www.youtube.com/watch?v=dDp3aj-eKXk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Covieta",
					"link": "https://youtu.be/r9uJD61eQEs",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Glacial Core",
			"author": "AcropolisBoy [rxmmybtw]",
			"more": "none",
			"id": 61842730,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=adUt1CqEUw0",
			"key": 45
		},
		/*=================================================================================*/
		{
			"vids": [
				{
                                       "user": "Amedxx2y",
                                       "link": "https://youtu.be/FOtOgWNbR5M",
                                       "percent": 100,
                                       "hz": "Mobile"
                                },
				{
					"user": "iRaily",
					"link": "https://youtu.be/_z9PRYNzC3o",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/oMzOSbLotqI",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/7-RR65b4Lbc",
					"percent": 100,
				        "hz": "Mobile"
				},
			        {
					"user": "Lightbolts",
					"link": "https://youtu.be/0sKePl8kpGs",
					"percent": 100,
				        "hz": "60hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=0HBbOY5rHZc",
					"percent": 100,
				        "hz": "240hz"
				},
				{
					"user": "justiceguy",
					"link": "https://www.youtube.com/watch?v=8ma6sNS0mUg",
					"percent": 100,
				        "hz": "60hz"
				},
				{
					"user": "GdWaaab",
					"link": "https://youtu.be/69DCN5Zb9TE",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=5Jnzkb-pb3o",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Surpl3x",
					"link": "https://youtu.be/mvvP3xVfo6Y",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Acidius",
					"link": "https://www.youtube.com/watch?v=f9gJHJrQ8ds",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Trollomggamer",
					"link": "https://youtu.be/v-i2A80il9U",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/NAhwILsxFOc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Whiteteeth",
					"link": "https://youtu.be/pRp_5UtS5c0",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "JTgaming7",
					"link": "https://www.youtube.com/watch?v=hoOUlhzqMHc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Gabe",
					"link": "https://youtu.be/irkN1-v4hWg",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Geometry Dash PJH",
					"link": "https://youtu.be/5POPLE5ScJs",
					"percent": 81,
					"hz": "Mobile"
				},
				{
					"user": "Cailloux",
					"link": "https://www.instagram.com/tv/CB8QDN3oOg4/",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/hYd-yJ9THr8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "FallenAresse",
					"link": "https://www.youtube.com/watch?v=RKFNrNZvOBU&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=r6AaNnoZHH0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "TH54",
					"link": "https://youtu.be/2L9ncSUyRd0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Dist3nd",
					"link": "https://youtu.be/Ev-J06dA7aQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Charlielance",
					"link": "https://youtu.be/GXpCmXTo8_w",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=lLFK-2OkXQc&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/K9mtshD2XC4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/wY9j2RSO8f0",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/696256569",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/HiokzFe4ngI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Blathers",
					"link": "https://youtu.be/QhmvLpOYFng",
					"percent": 91,
					"hz": "144hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/394bewBjfZY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "DJJDK",
					"link": "https://youtu.be/MtAKNcYPU-w",
					"percent": 91,
					"hz": "165hz"
				},
				{
					"user": "1987Evan",
					"link": "https://youtu.be/CCdwQMkA4qU",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Wave",
					"link": "https://youtu.be/iDr6A48F-Sk",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Blast",
					"link": "https://youtu.be/f_-8-HvY3BA",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Wrandom Stuff",
					"link": "https://youtu.be/iX6NyFXYQO8",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Quacc",
					"link": "https://www.youtube.com/watch?v=fTelq85JfjY&feature=youtu.be",
					"percent": 59,
					"hz": "240hz"
				},
				{
					"user": "Covieta",
					"link": "https://youtu.be/d88-9QN9ono",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Zshadoweye",
					"link": "https://www.youtube.com/watch?v=rgwBQolwSiU",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Xela343",
					"link": "https://www.youtube.com/watch?v=QJMxUGuOHgU",
					"percent": 100,
					"hz": "144hz"
				},
                        ],
			"name": "Shitty Kenos",
			"author": "Rexiture",
			"more": "none",
			"id": 58819416,
			"pass": "195563",
			"percentToQualify": 56,
			"verificationVid": "https://www.youtube.com/watch?v=prOytV0MGAQ",
			"key": 46
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://youtu.be/xGl72IQKGPM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/F_kWIMXD2tE?t=126",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=4Hi333RhjFM&t=",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "nIleum",
					"link": "https://youtu.be/1PD7C4BaOJc",
					"percent": 70,
					"hz": "300hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=fsZZtpOFl9A&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Cadrega City",
			"author": "Megum",
			"more": "none",
			"id": 46901184,
			"pass": "097643",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=6l2kNZpK9Qg",
			"key": 47
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "HdLink13",
					"link": "https://youtu.be/odrb39-aLvA",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=_Ksd6sKlD4g",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=NVVecRhUDwM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "lvcxs",
					"link": "https://youtu.be/wy3YX-b4WYQ",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "StarLight722",
					"link": "https://youtu.be/sziIi0QVYGA",
					"percent": 100,
					"hz": "Mobile"
				},
			],
			"name": "Shitty Omnitoxin",
			"author": "Segone and more [Segone]",
			"more": "Megum, Serpyy, yelloon, xSmajlik, oSpace, Ashvy, GDStarStorm",
			"id": 60391558,
			"pass": "947947",
			"percentToQualify": 59,
			"verificationVid": "https://www.youtube.com/watch?v=tYE2wRMixR0",
			"key": 48
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=K0L21LKiukc",
					"percent": 100,
					"hz": "240hz"
				},
				{
                                       "user": "Amedxx2y",
                                       "link": "https://youtu.be/iaYyMPBbIiE",
                                       "percent": 100,
                                       "hz": "Mobile"
                                },
				{
					"user": "Vink",
					"link": "https://youtu.be/9DwE0aH5iY4",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/6xKHQQiutZA",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=BZDfz_aLm_A&feature=youtu.be",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/u7tpPiY0fq4",
					"percent": 100,
					"hz": "300hz"
				},
			        {
                                        "user": "PriUsGD",
                                        "link": "https://youtu.be/YlaehvdmMLU",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
					"user": "AcropolisBoy",
					"link": "https://youtu.be/rdaSREovzJo",
					"percent": 70,
					"hz": "240hz"
				},
				{
					"user": "Bluuper",
					"link": "https://www.youtube.com/watch?v=DsposltVn94",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Whiteteeth",
					"link": "https://youtu.be/CuMVpAlcBSA",
					"percent": 77,
					"hz": "Mobile"
				},
				{
					"user": "Cyns",
					"link": "https://youtu.be/l7wkr3xxqdE",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "aurora",
					"link": "https://youtu.be/Hj5z-Ag5nF8",
					"percent": 65,
					"hz": "240hz"
				},
				{
					"user": "Tbocelot10",
					"link": "https://youtu.be/VXyoz7XC03M",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/2biRnWjyaSo",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Tonyearl",
					"link": "https://youtu.be/wcU2AeGIweA",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/6zBW6gLyoiY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/JZcTBJg4m9U",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TH54",
					"link": "https://youtu.be/LNh1WHjZkiw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/897quD-2eXg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GrimPencil16",
					"link": "https://youtu.be/dev1a1Z9kEM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/m-P1nu1psNA",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "crumche",
					"link": "https://cdn.discordapp.com/attachments/737134935881809963/737135852580503562/shitty_rate_demon.mp4",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "TheRealYeeter",
					"link": "https://youtu.be/OUShXF_tj3c",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Aassbll",
					"link": "https://youtu.be/bHdylIWaQsk",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Dashermachine",
					"link": "https://youtu.be/jY4nmfkf5Yw?t=162",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Zurteh",
					"link": "https://youtu.be/IG43uYpEp-k",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Zexer",
					"link": "https://www.youtube.com/watch?v=NBaS1C9ynzM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "lvcxs",
					"link": "https://youtu.be/QUZeuOGSA9Q",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Arcturus",
					"link": "https://youtu.be/C6Rd6EfsVdQ",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/NyUCMlmzIh8",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Just_Lemon",
					"link": "https://www.youtube.com/watch?v=5JPo-jf8cAA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "StarLight772",
					"link": "https://youtu.be/msWNa05B1rM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=nGM6pp-W7bo&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
                        ],
			"name": "Shitty Rate Demon",
			"author": "Serpyy",
			"more": "none",
			"id": 53652263,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=s9tbL0aa21U",
			"key": 49
		},
		/*=================================================================================*/
		{
			"vids": [
				{
                                        "user": "Amedxx2y",
                                        "link": "https://youtu.be/a5mC11bnHLk",
                                        "percent": 100,
                                        "hz": "mobile"
                                },
				{
					"user": "rVlaash",
					"link": "https://youtu.be/8L-Na4J4K10",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Whiliams8080",
					"link": "https://www.youtube.com/watch?v=VyUvTRpRqx0",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/bE4bL0W87Aw",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "GDStarStorm",
					"link": "https://www.youtube.com/watch?v=CDIK_kXNEYI&t",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=dP0NZhNn--k",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Phoee",
					"link": "https://youtu.be/xYenlch9MT0",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/F3J7eyyaXXo",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "NanCho",
					"link": "https://youtu.be/YNQ5OdRPLdU",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "hello2578",
					"link": "https://www.youtube.com/watch?v=iS8HDfqm9BY",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Chojang",
					"link": "https://youtu.be/Q9Z6a_-8_Lg",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "ItzRuPea",
					"link": "https://youtu.be/PtvIspqEYUU",
					"percent": 100,
					"hz": "30hz"
				},
				{
					"user": "Gloomy boy",
					"link": "https://www.youtube.com/watch?v=QjpJpPBhw3A",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Vaxer",
					"link": "https://m.youtube.com/watch?v=fXMirh8TNfY&t=24s",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/SgC6EfRBWOo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://youtu.be/Dyr_okpi9eI",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/7gTpPbClcx8",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "justiceguy",
					"link": "https://www.youtube.com/watch?v=RfY0iSnK-co",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Geometry Dash PJH",
					"link": "https://youtu.be/bpspH2ITmN4",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/Ab4GPLrpCAM",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "ShadowNinja441",
					"link": "https://youtu.be/AF4fS1BE55A",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Tonyearl",
					"link": "https://youtu.be/GqjXgPdp5Mo",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/iMSQd1aP_Fg",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Tbocelot10",
					"link": "https://youtu.be/hBa4WllR0p4",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Cushee",
					"link": "https://youtu.be/QtZ77-pAYDc",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Heath",
					"link": "https://www.youtube.com/watch?v=hyCesMI2YsM",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=EwV7_oheaz0&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/B8UE_kkbLpw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "ItsHyper37",
					"link": "https://www.youtube.com/watch?v=VdB90VaX3kY&t=18s",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "StarLight772",
					"link": "https://youtu.be/FhBu7Ky3qkc",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "YemenHD",
					"link": "https://youtu.be/4xIkPkNDmVM",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Celestial Force",
			"author": "Megum",
			"more": "none",
			"id": 50174445,
			"pass": "987123",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=01V2wiWS69o",
			"key": 50
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=6Y9PDKwLzXM",
					"percent": 100,
					"hz": "240hz"
				},
				{
                                        "user": "Amedxx2y",
                                        "link": "https://youtu.be/OevB71R5Ow0",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=JlR3k9QUFaE",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/yNGo1WQfBDo",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/PfrgtMnjSsE",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "GDTeabag",
					"link": "https://youtu.be/x_twWtlkzvA?t=10",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Chojang",
					"link": "https://youtu.be/GqgITM-NUGQ",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/9iMOBiuhWKc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Trollomggamer",
					"link": "https://youtu.be/lsIxukVVvCw",
					"percent": 78,
					"hz": "Mobile"
				},
				{
					"user": "ShadowNinja441",
					"link": "https://youtu.be/yN9pArmcZT0",
					"percent": 61,
					"hz": "Mobile"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/F_QTzu5-_u0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Pipzzzzzzz",
					"link": "https://youtu.be/8mCwpC2mLzY",
					"percent": 51,
					"hz": "240hz"
				},
				{
					"user": "DJJDK",
					"link": "https://youtu.be/JRba5uucny4",
					"percent": 69,
					"hz": "165hz"
				},
				{
					"user": "CarmenWinstead",
					"link": "https://www.youtube.com/watch?v=2sccv83MyDg",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Tonyearl",
					"link": "https://youtu.be/YDlm6XLlkMA",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Moosh",
					"link": "https://www.youtube.com/watch?v=4gTYBRqJ8BY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Pipzzzzzzz",
					"link": "https://youtu.be/DnuzItTbNMs",
					"percent": 58,
					"hz": "240hz"
				},
				{
					"user": "Makov",
					"link": "https://youtu.be/4wUVMp91qvQ",
					"percent": 51,
					"hz": "240hz"
				},
				{
					"user": "DasherMachine",
					"link": "https://www.youtube.com/watch?v=EnRE3lwt6xg&lc=UgzAVcK-M-qBBcSNEM54AaABAg",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/_xgywaUPKlU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/5nYw0zqw8yU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "FrostBurn",
					"link": "https://youtu.be/UXxUlDEH7Ps",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=Qys6spwXKYM",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Wadur",
					"link": "https://youtu.be/QShzZJAMeDo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Matter",
					"link": "https://www.youtube.com/watch?v=cBOpDBEaoz8",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Thinking Space",
			"author": "AcropolisBoy [timckic]",
			"more": "none",
			"id": 60598375,
			"pass": "Free to copy",
			"percentToQualify": 50,
			"verificationVid": "https://www.youtube.com/watch?v=8flvqLaJRDU",
			"key": 51
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Vink",
					"link": "https://youtu.be/qyuNGE711Tk",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/3I-vYaD0yG4",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/WiGydVcIpPY",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=1D88XQYvWq0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "justiceguy",
					"link": "https://www.youtube.com/watch?v=cmNpHZCc-6w",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/6er76pWej7Y?t=235",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Gloomy boy",
					"link": "https://youtu.be/TeY3Hy70vSk",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Bluuper",
					"link": "https://www.youtube.com/watch?v=09_XIes8zJ4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Matter",
					"link": "https://www.youtube.com/watch?v=7WA1p47Q64k",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/6n3sP7wq9OI",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Tonyearl",
					"link": "https://youtu.be/TxuZYl5jCkk",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/xi49KKyLB2o",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Veedio",
					"link": "https://www.youtube.com/watch?v=7pT2zkJKfpM&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "jToniX",
					"link": "https://youtu.be/0JqRESW8h9E",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "emberlol",
					"link": "https://youtu.be/pPCQZ-mrarQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=5vfWYcWiRtg&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Just_Lemon",
					"link": "https://www.youtube.com/watch?v=TVL6tXjOROU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Praerius",
					"link": "https://www.youtube.com/watch?v=muFlgGj77d4&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
			],
			"name": "Shitty Black Blizzard",
			"author": "Segone",
			"more": "none",
			"id": 49170614,
			"pass": "585585",
			"percentToQualify": 58,
			"verificationVid": "https://www.youtube.com/watch?v=Sxmp93oZvy4",
			"key": 52
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=7enQjQzJ66o",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/ete22W_2wE8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Tonyearl",
					"link": "https://youtu.be/p7YowFcwk7s",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/Mpyd_0_7D70",
					"percent": 100,
					"hz": "288hz"
				},
			],
			"name": "Shitty Skrillex Theory",
			"author": "LJosh",
			"more": "none",
			"id": 59558254,
			"pass": "0005",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=n3LgE_66ryc",
			"key": 53
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Soda",
					"link": "https://youtu.be/BIBi_g01Y78",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "rMinelo",
					"link": "https://youtu.be/xCtSxcKN2b8",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/fQI5TjcHbbc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=EHPusOnafyY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Gabe",
					"link": "https://youtu.be/WkTUBc-Kj-Q",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Amedxx2y",
					"link": "https://youtu.be/rc55Zg-Cuoo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Tonyearl",
					"link": "https://youtu.be/koYFi0-VKvM",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=L8Alnquqkes&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/z5ketr8zq7I",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/699015968",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/YygO8SKlp3Q",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Ad Aeternum",
			"author": "Vlaash and more [rVlaash]",
			"more": "TheKate, nezbednikSK, ZekronGD, Matafala",
			"id": 59629818,
			"pass": "159357",
			"percentToQualify": 56,
			"verificationVid": "https://www.youtube.com/watch?v=xMUEW3s8Bgs",
			"key": 54
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "ZekronGD",
					"link": "https://youtu.be/khDUrimLwGA",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=dPR4li-aO0g",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=KHX8KDLEkUY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/aR8wdh8H87g",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/JR0pyjD3DUc",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty PV II",
			"author": "Serpyy and more [Serpyy]",
			"more": "Keleru, Segone",
			"id": 61345238,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=0JPGc9NLaU0",
			"key": 55
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=rJcuv-zjSak&t=8s",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/fup4VwhPK4k",
					"percent": 100,
					"hz": "144hz"
				},
			        {
                                         "user": "Fhyron06",
                                         "link": "https://www.youtube.com/watch?v=6dys3PeoP38",
                                         "percent": 100,
                                         "hz": "240hz"
                                },
				{
                                         "user": "Kr_Flame",
                                         "link": "https://youtu.be/eZJVoIC8oDM",
                                         "percent": 100,
                                         "hz": "180hz"
                                },
				{
                                         "user": "iRaily",
                                         "link": "https://youtu.be/t_ve9hHjsqo",
                                         "percent": 100,
                                         "hz": "288hz"
                                },
				{
                                         "user": "N1kix",
                                         "link": "https://youtu.be/F_kWIMXD2tE?t=285",
                                         "percent": 100,
                                         "hz": "120hz"
                                },
				{
                                         "user": "MP3141",
                                         "link": "https://youtu.be/Q8WQnRBiq0k",
                                         "percent": 100,
                                         "hz": "144hz"
                                },
				{
                                         "user": "Forz1ple",
                                         "link": "https://youtu.be/FaH_kOgvaeA",
                                         "percent": 100,
                                         "hz": "216hz"
                                },
                        ],
			"name": "Shitty Omega",
			"author": "GDStarStorm and more [Megum]",
			"more": "AcropolisBoy, Megum, TheKate, Whiliams8080, ItzShuvon, HeizenSS, Serpyy",
			"id": 61607410,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=cGY6Y3hwCs0",
			"key": 56
		},
		/*=================================================================================*/
				{
			"vids": [
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/hsOM27LXBuY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=0PVJKKPhrqI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=PsryB2pqDgM&feature=youtu.be",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Amedxx2y",
					"link": "https://youtu.be/AINNvJDoams",
					"percent": 100,
					"hz": "Mobile"
				},
				{
                                        "user": "ViperVenom95",
                                        "link": "https://youtu.be/qE-xhzSMwaM",
                                        "percent": 100,
                                        "hz": "60hz"
                                },
				{
                                        "user": "Acidius",
                                        "link": "https://www.youtube.com/watch?v=aA1pTII2Xyw",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
					"user": "Vink",
					"link": "https://youtu.be/QLCgjLkb08E",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=BxaadTZkpS8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Aassbll",
					"link": "https://youtu.be/W7DgnpBIKaw",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "GDMeric",
					"link": "https://www.youtube.com/watch?v=_1lYJu681jc&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/C9dlsPLsGZk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Kanolli",
					"link": "https://www.youtube.com/watch?v=QpvFoC7nPBo",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Aiden",
					"link": "https://www.youtube.com/watch?v=_yjF68PvlOc",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Tbocelot10",
					"link": "https://youtu.be/CU_H0hXovaI",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/psr2m5yMZw0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/oHdg_paLFqs",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/iselO6CxRZ4",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Moosh",
					"link": "https://www.youtube.com/watch?v=ljnVB-An4Ic",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/nwJwpauE4JA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/HEINvZpNrCs",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "ThanosPig",
					"link": "https://youtu.be/xwlz48dMsPM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "HamburgerMan",
					"link": "https://www.youtube.com/watch?v=iQbSk_jiIMY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Dist3nd",
					"link": "https://youtu.be/OAeNFP8xZSU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Spacethug",
					"link": "https://youtu.be/ZkZ_rV6_6Fw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TheRealYeeter",
					"link": "https://youtu.be/dY600MCVQbg",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Wyaaronpc",
					"link": "https://youtu.be/t7zyKXgA43c",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Hixobit",
					"link": "https://www.youtube.com/watch?v=q-2K4-iPRXM",
					"percent": 100,
					"hz": "300hz"
				},{
					"user": "Zurteh",
					"link": "https://youtu.be/mBN17sut-HI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Makov",
					"link": "https://youtu.be/42-T3D5Val0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "lvcxs",
					"link": "https://youtu.be/n5qR1WPRlHA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/5f8eMVzNt1M",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Dashermachine",
					"link": "https://youtu.be/jY4nmfkf5Yw?t=81",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=YWiBTy1SIiI&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "CavEmaN_mElviN",
					"link": "https://www.youtube.com/watch?v=o_uVrbakW-o&list=PLAHT5vTrU-yiL3XyTFLt8XbRvYqQOXGIj&index=2&t=0s",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "TH54",
					"link": "https://youtu.be/QiVEG-WjbZg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bangaled",
					"link": "https://youtu.be/DTTL1kmbxZA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "aurora",
					"link": "https://youtu.be/4IhNU-_63MU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Nevise",
					"link": "https://youtu.be/h1h3r6SXoX8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XImaPlayerX",
					"link": "https://youtu.be/wPxJQfYrxAQ?t=333",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "InferiorPatty",
					"link": "https://www.youtube.com/watch?v=1AodoHnzmuE&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=iGd6wbp2eZY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Arcturus",
					"link": "https://youtu.be/AvLr44My8W8",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "JTgaming7",
					"link": "https://www.youtube.com/watch?v=scM1mWuEc-g",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bentai",
					"link": "https://www.youtube.com/watch?v=n60Ghruf7EU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=Z9ZigqfyxOc&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/698155940",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/uxeaKyDjh-E",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=6Fz5H7QlMjo",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "nileum",
					"link": "https://www.youtube.com/watch?v=qmeYiQGc3ao&t=2s",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Just_Lemon",
					"link": "https://www.youtube.com/watch?v=YwQ51DU1eiU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "KriSsi",
					"link": "https://www.youtube.com/watch?v=RxPt8Zkxvfk&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Xela343",
					"link": "https://www.youtube.com/watch?v=Ils4nzBGVWo",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Covieta",
					"link": "https://youtu.be/UDujQaQIG_I",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Devil Vortex",
			"author": "Vlaash",
			"more": "none",
			"id": 60330613,
			"pass": "137349",
			"percentToQualify": 58,
			"verificationVid": "https://www.youtube.com/watch?v=Of-jAU42U8k",
			"key": 57
		},
		/*=================================================================================*/
		{
			"vids": [
				{
                                         "user": "Fhyron06",
                                         "link": "https://www.youtube.com/watch?v=HA_TH-TgCiY",
                                         "percent": 100,
                                         "hz": "240hz"
                                },
                                {
                                         "user": "Soda",
                                         "link": "https://www.youtube.com/watch?v=kykh6GTmjjE&feature=youtu.be",
                                         "percent": 100,
                                         "hz": "75hz"
                                },
                                {
                                         "user": "XanPlayzGamez",
                                         "link": "https://youtu.be/A3wKlHl5IDI",
                                         "percent": 100,
                                         "hz": "144hz"
                                },
				{
                                         "user": "piesy",
                                         "link": "https://youtu.be/dmyXIAYLWRA",
                                         "percent": 100,
                                         "hz": "240hz"
                                },
				{
                                         "user": "Praerius",
                                         "link": "https://www.youtube.com/watch?v=fD7oegJNmFg&feature=youtu.be",
                                         "percent": 100,
                                         "hz": "288hz"
                                },
				{
					"user": "FrostBurn",
					"link": "https://youtu.be/M9yNoT7JOi4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=zQ5vJ_PEfQk&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://www.youtube.com/watch?v=Eowr6BFsRnc&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/Sx0MxsTJ_hM",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Abandoned Planet",
			"author": "LJosh",
			"more": "none",
			"id": 59558219,
			"pass": "000000",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=SG-STCb-UTU",
			"key": 58
		},
		/*=================================================================================*/
		{
			"vids": [
				{
                                         "user": "GDMeric",
                                         "link": "https://youtu.be/qBjlZECPKd0",
                                         "percent": 100,
                                         "hz": "144hz"
                                },
				{
                                         "user": "Fhyron06",
                                         "link": "https://www.youtube.com/watch?v=GCQ_3_i5xvg",
                                         "percent": 100,
                                         "hz": "240hz"
                                },
				{
                                         "user": "piesy",
                                         "link": "https://youtu.be/rlKOrlfqzCE",
                                         "percent": 100,
                                         "hz": "60hz"
                                },
				{
                                         "user": "chalielance",
                                         "link": "https://www.youtube.com/watch?v=F2nMJ5VidZ0",
                                         "percent": 100,
                                         "hz": "120hz"
                                },
				{
                                         "user": "jToniX",
                                         "link": "https://youtu.be/WKX4O_tvMIE",
                                         "percent": 100,
                                         "hz": "144hz"
                                },
				{
                                         "user": "Wyaaronpc",
                                         "link": "https://youtu.be/pfCXDTcKAMQ",
                                         "percent": 100,
                                         "hz": "144hz"
                                },
				{
					 "user": "Charlielance",
                                         "link": "https://www.youtube.com/watch?v=F2nMJ5VidZ0",
                                         "percent": 100,
                                         "hz": "120hz"
				},
				{
					 "user": "Zurteh",
                                         "link": "https://youtu.be/m_7-hLWEfYs",
                                         "percent": 94,
                                         "hz": "144hz"
				},
				{
					 "user": "Plasmic",
                                         "link": "https://www.youtube.com/watch?v=YDcNgNrbTzM&feature=youtu.be",
                                         "percent": 100,
                                         "hz": "300hz"
				},
				{
					 "user": "Tai0",
                                         "link": "https://www.twitch.tv/videos/696224275",
                                         "percent": 100,
                                         "hz": "120hz"
				},
				{
					 "user": "TFIBB",
                                         "link": "https://www.youtube.com/watch?v=zh5I088s7vI",
                                         "percent": 100,
                                         "hz": "144hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/1Dcf5XucQ50",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "UNarwall",
					"link": "https://www.youtube.com/watch?v=_kP1pL_KulA&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://www.youtube.com/watch?v=t00imbixk_4&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Forz1ple",
					"link": "https://www.youtube.com/watch?v=lMnAL71iTWA",
					"percent": 100,
					"hz": "216hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/VS6OQhzBHiA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "domi77",
					"link": "https://youtu.be/LZnVQBpFF0o",
					"percent": 59,
					"hz": "240hz"
				},
				{
					"user": "bletzee",
					"link": "https://www.youtube.com/watch?v=JXjjj-S7VKw",
					"percent": 71,
					"hz": "144hz"
				},
				{
					"user": "Hixobit",
					"link": "https://www.youtube.com/watch?v=NdKxcFVsfz8&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
			],
			"name": "Shitty Bloodbath",
			"author": "AcropolisBoy [LJosh]",
			"more": "none",
			"id": 57920890,
			"pass": "Not copyable",
			"percentToQualify": 59,
			"verificationVid": "https://youtu.be/1Y1T2UdSCEY?t=2425",
			"key": 59
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/nw2OoLZu1gg",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/7HbyUNUkCl8",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "PriUsGD",
					"link": "https://youtu.be/IW81v479Usc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=osBGzEebpxE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=uISx8m7rZPs&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/HiHxrFkxSCA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/Slky5On0bAE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://www.youtube.com/watch?v=bcF--eldRO8&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Explosion",
			"author": "Serpyy",
			"more": "none",
			"id": 57580516,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=I7BGa0HFusI",
			"key": 60
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=UNk3d5ub0pg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Amedxx2y",
					"link": "https://youtu.be/cF727HoCuTY",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/VVH_cP_CJSs",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Aassbll",
					"link": "https://youtu.be/JPseMwMJDe4",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=_KO2XXht08Q",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/FE_3eM8PQbU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=ncvp5BLZz6s&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/wSQ2Nu7dTDA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/MiK-jN8bbDk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/pUhQmO_Ml08",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/oSN_301irWM",
					"percent": 100,
					"hz": "288hz"
				},
			],
			"name": "Shitty Penombre",
			"author": "Miini03",
			"more": "none",
			"id": 56802357,
			"pass": "Not copyable",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=jhu_OkP0rNY",
			"key": 61
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=mPhVpA2g2EM&t=11s",
					"percent": 100,
					"hz": "200hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/tW25q_3XIuU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/89BuUOym07M",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/XrITgYt06sM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=JEdVIplYmmg&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/favZqo0bnhs",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/OQDgTMDqWOg",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Battle of the Shades",
			"author": "xSmajlik and Superxman777 [xSmajlik]",
			"more": "none",
			"id": 59275488,
			"pass": "130919",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=mPhVpA2g2EM",
			"key": 62
		},
		/*=================================================================================*/
		{
			"vids": [
			],
			"name": "Shitty Distraught",
			"author": "AlexTheGS33 and more [AlexTheGS33]",
			"more": "Megum, SoyNadie, ItzShuvon, FKaDeR, Synthicam, MiiNi03, ImColdBlast, ShadowNinja441, oSpace, Depressionate7, GDStarStorm",
			"id": 56698630,
			"pass": "258852",
			"percentToQualify": 59,
			"verificationVid": "https://www.youtube.com/watch?v=KcphTwbl2wc",
			"key": 63
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "GdWaaab",
					"link": "https://youtu.be/c-8rDf08_Gc",
					"percent": 83,
					"hz": "Mobile"
				},
				{
                                        "user": "Amedxx2y",
                                        "link": "https://youtu.be/eQtUBjtDogY",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
			        {
				        "user": "Whiliams8080",
					"link": "https://www.youtube.com/watch?v=jUs2PRbtB88",
					"percent": 100,
					"hz": "120hz"
			        },
			        {
				        "user": "XanPlayzGamez",
					"link": "https://youtu.be/w_UJ-IkSqhY",
					"percent": 100,
					"hz": "120hz"
			        },
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=uTTagDEZSHk",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://youtu.be/wyv6OSJ_EeI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Phoee",
					"link": "https://youtu.be/pBP22qh18vM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Gloomy boy",
					"link": "https://youtu.be/neCIOR6mFZM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Vaxer",
					"link": "https://m.youtube.com/watch?v=z7yH-HtqR8Y",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Chojang",
					"link": "https://youtu.be/f30L-BOk6yA",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/Ohp-0zkC_1I",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=D7leo4_EvPg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/MA4Bz7mHVt8",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "md1159",
					"link": "https://youtu.be/AJses-tmw3M",
					"percent": 100,
					"hz": "Mobile"
				},
				{
                                        "user": "N1kix",
                                        "link": "https://youtu.be/q0ZmKhOgkks",
                                        "percent": 100,
                                        "hz": "120hz"
                                },
				{
                                        "user": "TH54",
                                        "link": "https://youtu.be/JBe0XHQfWc0",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "Creatormichaelr",
                                        "link": "https://youtu.be/zAyUqb3zTGI0",
                                        "percent": 100,
                                        "hz": "300hz"
                                },
				{
					"user": "Baechukimchi",
                                        "link": "https://www.youtube.com/watch?v=1CsZqUoG8gU",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "Bluuper",
                                        "link": "https://youtu.be/wgYpfjdEU_c",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "MythicalTG",
                                        "link": "https://youtu.be/s2ww6jiDegg",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "Th13teen",
                                        "link": "https://www.youtube.com/watch?v=kE0wHZCE_8E&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/Ajlg0JksgyA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "StarLight722",
					"link": "https://youtu.be/GZlQOGxvTRo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Narwall",
					"link": "https://youtu.be/9bL6DRLFIzA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/Ro0HMT1yMxg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/RHGWh9So2oo",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Factory Realm X",
			"author": "Megum",
			"more": "none",
			"id": 48073424,
			"pass": "375209",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=cUz5AlXaXxU",
			"key": 64
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=-vn24CnBqoA",
					"percent": 100,
					"hz": "240hz"
				},
				{
                                       "user": "Amedxx2y",
                                       "link": "https://youtu.be/hNa_IZi3APc",
                                       "percent": 100,
                                       "hz": "Mobile"
                                },
				{
					"user": "Soda",
					"link": "https://youtu.be/vMDsbpYj_C8",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/-D3mTcGYbOI",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://www.youtube.com/watch?v=d5fesaV1_SI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/xiWi3y9Qt48",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "SlayTrixx",
					"link": "https://youtu.be/dQfwROlwt0M",
					"percent": 95,
					"hz": "60hz"
				},
				{
					"user": "ZekronGD",
					"link": "https://youtu.be/VpVUGmdKFG0",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/K9djNkV8FTw",
					"percent": 100,
					"hz": "Mobile"
				},
				{
                                        "user": "N1kix",
                                        "link": "https://youtu.be/q0ZmKhOgkks",
                                        "percent": 100,
                                        "hz": "120hz"
                                },
				{
                                        "user": "Cyns",
                                        "link": "https://youtu.be/JmANfMH3xmo",
                                        "percent": 100,
                                        "hz": "288hz"
                                },
				{
                                        "user": "Cailloux",
                                        "link": "https://www.instagram.com/tv/CCaqY2pIXuL/",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
                                        "user": "nayf",
                                        "link": "https://youtu.be/iTj6FSNSIW4",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "Baechukimchi",
                                        "link": "https://www.youtube.com/watch?v=XaJU5yk-82E",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
                                        "user": "GDMeric",
                                        "link": "https://youtu.be/b21Bqbyhm7U",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
                                        "user": "WowoGD",
                                        "link": "https://youtu.be/ek1vpWNHuDY",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
					"user": "TH54",
                                        "link": "https://youtu.be/DQBH5gG0IVI",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "Creatormichaelr",
                                        "link": "https://youtu.be/sTY01LfooWc",
                                        "percent": 100,
                                        "hz": "300hz"
				},
				{
					"user": "xBlur",
                                        "link": "https://youtu.be/Ccmgzsypw-w",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "Bluuper",
                                        "link": "https://youtu.be/tKhCmNhYtGs",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/kwSSGpg2too",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Veedio",
					"link": "https://youtu.be/606WFvY2dQw",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Pipzzzzzzz",
					"link": "https://youtu.be/GPeYeUawslE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TheRealYeeter",
					"link": "https://youtu.be/7ogohe6sF0g",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "GDWish",
					"link": "https://youtu.be/vwYkQcDVCsA",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "SlayTrixx",
					"link": "https://youtu.be/r3TDjhLywZ8",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Charlielance",
					"link": "https://www.youtube.com/watch?v=sVtYsS7FyoU",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "ThanosPig",
					"link": "https://youtu.be/nWqytF7NwAI",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=vyFKDF_osP4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Makov",
					"link": "https://youtu.be/6kLwNXWqR2Q",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Zurteh",
					"link": "https://youtu.be/jtSvvJShqMc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Arctic",
					"link": "https://youtu.be/gKWvdwj8RZk",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "zArctic",
					"link": "https://youtu.be/Mp2aSQCs6qU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=CBkre8jos5g&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "suseJRG",
					"link": "https://youtu.be/HP0jYZGbFjw",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/cSw5OVpN6IE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Dashermachine",
					"link": "https://youtu.be/jXuslA3l9Fs",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "StarLight722",
					"link": "https://youtu.be/iBNuq01WN08",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Just_Lemon",
					"link": "https://www.youtube.com/watch?v=_uFYoNF3I-U",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/SaK37XstL8o",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "ItsHyper37",
					"link": "https://www.youtube.com/watch?v=ZYJE4avpe04",
					"percent": 96,
					"hz": "Mobile"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/ZjFxqi3Rn1k",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "UNarwall",
					"link": "https://www.youtube.com/watch?v=1Fbp_i9TF9M&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "avrg",
					"link": "https://www.youtube.com/watch?v=tR0cRmf_Vgk",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Xela343",
					"link": "https://youtu.be/JLQBhbyHptI",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "quacc",
					"link": "https://youtu.be/N7mftzWGNmw",
					"percent": 72,
					"hz": "240hz"
				},
				{
					"user": "eafan0",
					"link": "https://youtu.be/dKVQ6tiIRuM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/6Ghq9YZkd4A",
					"percent": 100,
					"hz": "180hz"
				},
			],
			"name": "Shitty VendetTa",
			"author": "Megum",
			"more": "none",
			"id": 52617967,
			"pass": "Free to copy",
			"percentToQualify": 58,
			"verificationVid": "https://www.youtube.com/watch?v=-u-ijZwZuz4",
			"key": 65
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=RhtQJDRShS8",
					"percent": 100,
					"hz": "240hz"
				},
				{
                                       "user": "Amedxx2y",
                                       "link": "https://youtu.be/UST1c83h7ZA",
                                       "percent": 100,
                                       "hz": "Mobile"
                                },
				{
					"user": "TheRealSiel07",
					"link": "https://youtu.be/7SAawxqxzKM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/UBGBp6p6Qcs",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=PAkbrlaDjtU&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "azizRCL",
					"link": "https://www.youtube.com/watch?v=jFev-_SsVCg",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "HdLink13",
					"link": "https://youtu.be/Qkp4U8pFLvU",
					"percent": 67,
					"hz": "60hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/scMIIKYi-B0",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Trollomggamer",
					"link": "https://youtu.be/LoIw-6Achc8",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/cdDiK_Ug6ZU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/SIZBylbAK5g",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "StatiicBluey",
					"link": "https://youtu.be/HNuFMTYj71U",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Hulunn",
					"link": "https://www.youtube.com/watch?v=DL0RxLgqXbc",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/uQjjkRQ-iyI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=yaakDbplIHk&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/Cg5CNYkHuPw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Darkys",
					"link": "https://youtu.be/pMAWlpmy314",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Blast",
					"link": "https://youtu.be/_MIwIzYky7k",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/so0HsNiN7cY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Narwall",
					"link": "https://youtu.be/wWcbObbh6gc",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Novavsn",
					"link": "https://youtu.be/CeRbj3kRiF4",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/yVVGVgZC1N0",
					"percent": 100,
					"hz": "288hz"
				},
			],
			"name": "Shitty Zodiac",
			"author": "oSpace",
			"more": "none",
			"id": 53858796,
			"pass": "Free to copy",
			"percentToQualify": 60,
			"verificationVid": "https://www.youtube.com/watch?v=lFD9lHR562E",
			"key": 66
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Phoee",
					"link": "https://youtu.be/vNiG_rMux-Q",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "md1159",
					"link": "https://www.youtube.com/watch?v=FWYFZfiJQ84&feature=youtu.be",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=OFXGwLRCsfo&list=PL5lAe2NjqiU4rWNSVvBCt_dWPG5ScW3dg&index=46",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/B6oJvRzyLTc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/cB3KuqiQVKs",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "TH54",
					"link": "https://youtu.be/PPwyuQmRkQY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/3mZ0bpMQTcg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/ojZano1wByE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Questionblockg",
					"link": "https://youtu.be/EKCTVHlA3h0",
					"percent": 75,
					"hz": "Mobile"
				},
				{
					"user": "Deados35",
					"link": "https://youtu.be/Pg0g1BKohJQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "XImaPlayerX",
					"link": "https://youtu.be/wPxJQfYrxAQ?t=153",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/SAIXgW3Tp_A",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "mrbananan",
					"link": "https://www.youtube.com/watch?v=dwJ3z_QAZFs&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Jah",
					"link": "https://www.youtube.com/watch?v=AqgejGkdu1M&feature=youtu.be",
					"percent": 76,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=dYaH-4yARKI&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/X5-c0Rp0Mac",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=jAQ7i3mEtM0",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Anoxysm",
			"author": "Serpyy",
			"more": "none",
			"id": 57446558,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=f8Ih6EaNugI",
			"key": 67
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Vink",
					"link": "https://youtu.be/lhwTPaYD35w",
					"percent": 100,
					"hz": "120hz"
				},
			],
			"name": "Shitty Firepower",
			"author": "AcropolisBoy [GDTeaBag]",
			"more": "none",
			"id": 56139903,
			"pass": "661616",
			"percentToQualify": 60,
			"verificationVid": "https://www.youtube.com/watch?v=a8Qe1S3HLDU",
			"key": 68
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "GDMeric",
					"link": "https://youtu.be/aXFAt1oRyj8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Zurteh",
					"link": "https://youtu.be/IA6qxID5TZ8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "ThanosPig",
					"link": "https://youtu.be/cG83WV_6k7Q",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=0X90DmVlN70",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Cyns",
					"link": "https://youtu.be/CGdV6PIqTr8",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Dashermachine",
					"link": "https://youtu.be/jY4nmfkf5Yw",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/U8Yolh24YJ0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/696193106",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=9lR8LAlMWSk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "StarLight722",
					"link": "https://youtu.be/lxB5b2vRI6I",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/rQlrduYxLII",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "zriv",
					"link": "https://youtu.be/qFAnrjQ-KhQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Narwall",
					"link": "https://youtu.be/QM0EQzMZDTo",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Gherkin",
					"link": "https://youtu.be/vkUvNPN9yfg",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Forz1ple",
					"link": "https://www.youtube.com/watch?v=vcnZ4-xUz0o&feature=youtu.be",
					"percent": 100,
					"hz": "72hz"
				},
			],
			"name": "Shitty Plasma Pulse",
			"author": "Aassbll",
			"more": "none",
			"id": 58030170,
			"pass": "Free to copy",
			"percentToQualify": 58,
			"verificationVid": "https://www.youtube.com/watch?v=w_UX8sAnXkE",
			"key": 69
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "rVlaash",
					"link": "https://youtu.be/WblsmOFsrlc",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Whiliams8080",
					"link": "https://www.youtube.com/watch?v=MdzVDMTo4Fs",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=i4K8TkM04qo",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/VRRc2D2Bk0I",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=MZ7TO8XnBb4",
					"percent": 100,
					"hz": "270hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=NStsNppY_OY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "md1159",
					"link": "https://youtu.be/P84VtDFsK-8",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Bluuper",
					"link": "https://www.youtube.com/watch?v=6gTsCe-bD1s",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "FrEnchKebAb",
					"link": "https://youtu.be/NHtVW5SbSUI",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/KWSN6cfDh1Y",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/PFeYx_djxLc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=OV7bP4tPQ7o&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Narwall",
					"link": "https://youtu.be/gMew-zgIClk",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Concaved Memories",
			"author": "oSpace",
			"more": "none",
			"id": 57704931,
			"pass": "Free to copy",
			"percentToQualify": 59,
			"verificationVid": "https://www.youtube.com/watch?v=WCJzAF1EZmk",
			"key": 70
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=RaPMQj62Yqs",
					"percent": 100,
					"hz": "75hz"
			        },
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=PjpUtXVZutM",
					"percent": 100,
					"hz": "240hz"
			        },
				{
					"user": "piesy",
					"link": "https://youtu.be/yWzG5PX3uXE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=ph5Cif2ED3U",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/bIK4hfrUtCs",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/44s4vGzr_a0",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Baechukimchi",
					"link": "https://www.youtube.com/watch?v=NhQx_IGMHqE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/hD-k6DNOBng",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/qczRgts6UHA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/bJmSHxNf5vM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "BOSTONTHEKIDRS",
					"link": "https://youtu.be/MPRMl52rLOg",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Arctic",
					"link": "https://youtu.be/oQTqve3ID1s",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Arcturus",
					"link": "https://youtu.be/ElFkqa1OoRA",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/DiJuTcL_6PI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Narwall",
					"link": "https://youtu.be/6cXDbVNTpEU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=KcljiUSE3ls&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "KriSsi",
					"link": "https://www.youtube.com/watch?v=Dpj4GrPfBDU&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Just Dance",
			"author": "PotatoManPlays",
			"more": "none",
			"id": 62379756,
			"pass": "150620",
			"percentToQualify": 58,
			"verificationVid": "https://youtu.be/TwBHuCPo6DA",
			"key": 71
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/QJBjl5TlrnM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=y8iGDQBObIA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/F_kWIMXD2tE",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/UnLDOyNWrvs",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Batle",
					"link": "https://youtu.be/2egLEnqpgBc",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/2egLEnqpgBc",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Bluuper",
					"link": "https://www.youtube.com/watch?v=e8smOCv-J5E",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "mikey100mike",
					"link": "https://www.youtube.com/watch?v=MvpvJt1gQmg",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/8YzNvQk64wM",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Novalis",
			"author": "Megum",
			"more": "none",
			"id": 44568953,
			"pass": "Not copyable",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=qP0v6diamBM",
			"key": 72
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Renar333",
					"link": "https://youtu.be/9pkF6dV1XLk",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=9TNY4VXrUdg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Praerius",
					"link": "https://www.youtube.com/watch?v=0faTbqXmCx8&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/90GOlLsA_zY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=lfi6uv32kAg&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/QPofua90U78",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "StarLight722",
					"link": "https://youtu.be/-VqtoEb6N1U",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Narwall",
					"link": "https://youtu.be/g_h3wcN6t58",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/uiZwaHOj7-Y",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/LFB67T5D8sw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Covieta",
					"link": "https://youtu.be/qq6i4-jGpSI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "ZekronGD",
					"link": "https://youtu.be/h9b1JB8IjkM",
					"percent": 100,
					"hz": "Mobile"
				},
			],
			"name": "Shitty Silver Shade",
			"author": "Aassbll",
			"more": "none",
			"id": 58313219,
			"pass": "Free to copy",
			"percentToQualify": 59,
			"verificationVid": "https://www.youtube.com/watch?v=xfNYS-XFZ1Y",
			"key": 73
		},
		/*=================================================================================*/
		{
                        "vids": [
				{
					"user": "TH54",
					"link": "https://youtu.be/QCxiGpdu6K8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/wWfq8h0SeIM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Moosh",
					"link": "https://www.youtube.com/watch?v=JuGj7aj1oyQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=np8B4f-cWn8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=1AySuJ0Dzf0&feature=youtu.be",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "MiniShoey",
					"link": "https://youtu.be/umgxfRuWYfk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/yWD-EskK0DI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/9GZkpwtPn7A",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/q8llNdwyjyc",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Wyaaronpc",
					"link": "https://youtu.be/-RDBi1J-LVU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/2-AFWCTWV3I",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "aurora",
					"link": "https://youtu.be/lz_G4g_zTjk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Zirkitri",
					"link": "https://youtu.be/jopHgAILLms",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Zurteh",
					"link": "https://youtu.be/2157xqHaI-0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Charlielance",
					"link": "https://www.youtube.com/watch?v=VibJFGJ5XtE",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "TheRealYeeter",
					"link": "https://youtu.be/zPOqKpYNbJo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Makov",
					"link": "https://www.youtube.com/watch?v=KZ6YPbVxn9k",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Hulunn",
					"link": "https://www.youtube.com/watch?v=Kr-AbWnESCA",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "jToniX",
					"link": "https://youtu.be/YC3LUHTBAH8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Dashermachine",
					"link": "https://youtu.be/jY4nmfkf5Yw?t=333",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "DomanikGD",
					"link": "https://www.youtube.com/watch?v=falDjPuq1Y8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=mr-ZzrqQZ2c&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=tICOStLc5yA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/GVawsn5p9Uo",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "CavEmaN_mElviN",
					"link": "https://www.youtube.com/watch?v=dDPFnlT4Cy8",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/696188053",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Yaev",
					"link": "https://www.youtube.com/watch?v=TocGnHJi_jk&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bentai",
					"link": "https://www.youtube.com/watch?v=l3E6wUgFk7Y",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XImaPlayerX",
					"link": "https://youtu.be/wPxJQfYrxAQ?t=745",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "RageRod",
					"link": "https://youtu.be/Vz1rt8ftMEQ",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/BFNnstJI9z8",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/9qRxe7ctspI",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/qtH6fFL9EDE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "InferiorPatty",
					"link": "https://www.youtube.com/watch?v=5CT8JJNnELM&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Just_Lemon",
					"link": "https://www.youtube.com/watch?v=AertgIuf8_U&t=1s",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/b7P_TO0m6Ws",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Wadur",
					"link": "https://youtu.be/DU8wIe3yYKY",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "FoZard",
					"link": "https://www.youtube.com/watch?v=tXsZzdYKSHQ",
					"percent": 100,
					"hz": "165hz"
				},
				{
					"user": "Emonadeo",
					"link": "https://www.youtube.com/watch?v=zvvmX8WrpOc",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "FrostBurn",
					"link": "https://www.youtube.com/watch?v=P_Swe23RYJ8&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Arcturus",
					"link": "https://youtu.be/HaTbGO0lktc",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Spacethug",
					"link": "https://youtu.be/zJ9Rj-DeNPs",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Xela343",
					"link": "https://www.youtube.com/watch?v=tCtaS6_JCNE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Covieta",
					"link": "https://youtu.be/6fD0wSXmhrs",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Hixobit",
					"link": "https://www.youtube.com/watch?v=DsZkMLMmRTM",
					"percent": 100,
					"hz": "300hz"
				},
	                ],
                        "name": "Shitty Cataclysm",
                        "author": "AcropolisBoy [LJosh]",
                        "more": "none",
                        "id": 57920891,
                        "pass": "444446",
                        "percentToQualify": 61,
                        "verificationVid": "https://www.youtube.com/watch?v=LeykUbA7N5Y&t=44s",
                        "key": 74
                }, 
		/*=================================================================================*/
		{
                        "vids": [
				{
                                        "user": "Soda",
                                        "link": "https://www.youtube.com/watch?v=OA1MVGVfee0&t=3s",
                                        "percent": 100,
                                        "hz": "75hz"
                                },
                                {
                                        "user": "nayf",
                                        "link": "https://www.youtube.com/watch?v=-CT6hpRXUEU&pbjreload=101",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "Fhyron06",
                                        "link": "https://www.youtube.com/watch?v=tHpuU-uqQ4k",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
					"user": "Bluuper",
					"link": "https://www.youtube.com/watch?v=FAFUzoz3FaI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Zshadoweye",
					"link": "https://www.youtube.com/watch?v=frbZPXJnWi8",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Ultraviolet",
					"link": "https://www.youtube.com/watch?v=e144nZXLJaM",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/fMg9HxkKXaA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/bzvyocg_7u4",
					"percent": 100,
					"hz": "144hz"
				},
	                ],
                        "name": "Shitty Ethereal Artifice",
                        "author": "Megum and more [Megum]",
                        "more": "AcropolisBoy, nezbednikSK, Flexihtala, TheKate, GDStarStorm, NezbednikSK, Aassbll, md1159",
                        "id": 61355501,
                        "pass": "Free to copy",
                        "percentToQualify": 51,
                        "verificationVid": "https://www.youtube.com/watch?v=0wzYbY7pyxA",
                        "key": 75
                }, 
		/*=================================================================================*/
		{
			"vids": [
				{
                                        "user": "Amedxx2y",
                                        "link": "https://youtu.be/rc2yxlVzHX4",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
					"user": "Roke556",
					"link": "https://www.youtube.com/watch?v=CrutPAWjQLo",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/XsLMUuRY8M4",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=ENvgkRyRp-g",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "GDTeaBag",
					"link": "https://www.youtube.com/watch?v=w3XBWFIca2w&lc=Ugx5RJoeP2_-Ot2eY8J4AaABAg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=2TU7uX6uwXc&t=8s",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/PUEgBQjAvEE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://youtu.be/iVqXMwGq7lU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "SaTang",
					"link": "https://youtu.be/8HnOnREnrcw",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=AGxQhqB2uqU",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Gloomy boy",
					"link": "https://youtu.be/W2bq3jgtw3A",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=ZqzyJCUi3iM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/AxktHwJNsMo",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/6er76pWej7Y?t=363",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "md1159",
					"link": "https://youtu.be/sy8ykXT3f24",
					"percent": 100,
					"hz": "Mobile"
				},
                                {
					"user": "DJJDK",
					"link": "https://www.twitch.tv/videos/689534889",
					"percent": 100,
					"hz": "165hz"
				},
				{
					"user": "TH54",
					"link": "https://youtu.be/P14JP5BvYQQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Matter",
					"link": "https://www.youtube.com/watch?v=XUjhTEikPqU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Blathers",
					"link": "https://www.youtube.com/watch?v=N_mFhFGiFJ8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Baechukimchi", 
					"link": "https://www.youtube.com/watch?v=MBoQaR2lCzQ&t=3s",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bluuper", 
					"link": "https://youtu.be/egAwDtby4lU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Darkrai26", 
					"link": "https://youtu.be/TuOGqJyDORI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Nevise", 
					"link": "https://youtu.be/cxUXlSX6Oes",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TheRealYeeter",
					"link": "https://youtu.be/z95vHioRyLc",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "GrimPencil16",
					"link": "https://youtu.be/Yv9TPylJvxs",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=BKb7zHK2vB0&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Acute",
					"link": "https://www.youtube.com/watch?v=bZ0o9zUnVZ0",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=Hrmc3su1w5E&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/qLMzX3HM4kw",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/D4KrddmTjLE",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Heath",
					"link": "https://www.youtube.com/watch?v=uBF6X39kdOg",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "VdT",
					"link": "https://youtu.be/AJFkV1kZLyY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Ultraviolet",
					"link": "https://youtu.be/s8ZnlacYUs0",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/Ww2se8d4gIQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/3b2wyy6Ys_A",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Poptart",
					"link": "https://youtu.be/4VLdquNe8TM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "MacJubber",
					"link": "https://youtu.be/TaBU6nLbOKc",
					"percent": 100,
					"hz": "300hz"
				},
			],
			"name": "Shitty Dolos",
			"author": "Acropolisboy and more [Whiliams8080]",
			"more": "Whiliams8080, Megum, TheKate, Serpyy, ItzShuvon, GDStarStorm",
			"id": 61355408,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=NbcF_4EgMXI",
			"key": 76
		},
		/*=================================================================================*/
		{
                        "vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=ua_x9jkQYw8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/tcDkAgXnBXs",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=DuKQxM2bBXE",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/gokIMTNX7po",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/Ykdj_EIjp_c",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Pipzzzzzzz",
					"link": "https://youtu.be/_PHaYg_SD3I",
					"percent": 56,
					"hz": "240hz"
				},
				{
					"user": "Amedxx2y",
					"link": "https://youtu.be/aJTKLF2P2xs",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/DxzTaCXm-lg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/ymm1n5_Lue8",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "HdLink13",
					"link": "https://youtu.be/BexhA1AOU8A",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=OsDxCsAVRCc&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Zshadoweye",
					"link": "https://www.youtube.com/watch?v=VD3yHy2Q4ZA",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/_piL6N7r_UM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=xjXUSqjHHmc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/Dr-jdlFEJJE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "lNEFIX",
					"link": "https://youtu.be/by47Fuz0YqA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "YellowDoopAlt",
					"link": "https://omlet.gg/v/atBvReGrglWHzLRMO",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "GDWish",
					"link": "https://youtu.be/f1M0MDMpHZ8",
					"percent": 100,
					"hz": "300hz"
				},
                        ],
                        "name": "Shitty Ouroboros",
                        "author": "Megum",
                        "more": "none",
                        "id": 56855749,
                        "pass": "735735",
                        "percentToQualify": 53,
                        "verificationVid": "https://www.youtube.com/watch?v=A-hl2gVl1aE",
                        "key": 77
                },
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=PCyVkPugdio",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Vaxer",
					"link": "https://m.youtube.com/watch?v=ieMMVuIMZKM",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/TEi0zl0GIyc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "amedxx2y",
					"link": "https://youtu.be/4rSTiy3IF5w",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "eafan0",
					"link": "https://youtu.be/80DdoD5VwE4",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Vaxer",
					"link": "https://m.youtube.com/watch?v=ieMMVuIMZKM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/F4oVDGJtpz0",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=yrUjbDpVqN4&list=PL5lAe2NjqiU4rWNSVvBCt_dWPG5ScW3dg&index=38",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/oHEifXBUIr4",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "justiceguy",
					"link": "https://www.youtube.com/watch?v=Ep5coVf5QB8",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "md1159",
					"link": "https://youtu.be/3b72dgI_EnY",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/WXRu9MTYO0I",
					"percent": 100,
					"hz": "360hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/F246R6RLznY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=a0oL2EsWk-4&feature=youtu.be",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "GDMeric",
					"link": "https://www.youtube.com/watch?v=twF685Ao1YA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "jToniX",
					"link": "https://youtu.be/jHg9iHYqluk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "TH54",
					"link": "https://youtu.be/EVVkg2NXeL0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Zexer",
					"link": "https://www.youtube.com/watch?v=Rh18D_IW92Y",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/DVFh8poZYNU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/ZSwM7MGx8M0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Creatormichealr",
					"link": "https://youtu.be/MH1T0d-npqE",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/2pW4dms70ec",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Forz1ple",
					"link": "https://www.youtube.com/watch?v=CNwbNg_fxU0",
					"percent": 100,
					"hz": "72hz"
				},
				{
					"user": "Just_Lemon",
					"link": "https://www.youtube.com/watch?v=NnqU3KVhyqY",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Blade of Justice",
			"author": "oSpace and more [oSpace]",
			"more": "ZenrioL, AlexTheGS33, Megum, xSmajlik, ShadowNinja441",
			"id": 51744070,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=q-P4ybSLZP4",
			"key": 78
		},
		/*=================================================================================*/
		{
                       "vids": [
			       {
				       "user": "XanPlayzGamez",
				       "link": "https://youtu.be/mjR5jie7d_Q",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "RG",
				       "link": "https://www.youtube.com/watch?v=BxaadTZkpS8",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "Cyns",
				       "link": "https://youtu.be/e7rFSg5vvr8",
				       "percent": 100,
				       "hz": "288hz"
			       },
			       {
				       "user": "Fhyron06",
				       "link": "https://www.youtube.com/watch?v=dOFUNH15v-M",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "GDMeric",
				       "link": "https://youtu.be/NK_TfQKAdwI",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "aurora",
				       "link": "https://youtu.be/nlZNt1F9ptU",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "Evilperson34",
				       "link": "https://www.youtube.com/watch?v=auqTk_AMguI&feature=youtu.be",
				       "percent": 100,
				       "hz": "280hz"
			       },
			       {
				       "user": "nayf",
				       "link": "https://youtu.be/curqSg4FFfk",
				       "percent": 100,
				       "hz": "360hz"
			       },
			       {
				       "user": "TH54",
				       "link": "https://youtu.be/WhjVxYZIBsw",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "Alphanetic",
				       "link": "https://youtu.be/teN6cpebxqY",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "Tbocelot10",
				       "link": "https://youtu.be/ywPx74z4qQc",
				       "percent": 100,
				       "hz": "60hz"
			       },
			       {
				       "user": "Gherkin",
				       "link": "https://youtu.be/B43T4uPNnzs",
				       "percent": 100,
				       "hz": "Mobile"
			       },
			       {
				       "user": "Ensanity",
				       "link": "https://youtu.be/mjaRWTAoldQ",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "MiniShoey",
				       "link": "https://youtu.be/zatAUEb0stA",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "WowoGD",
				       "link": "https://youtu.be/_8utgTYcVw8",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "Matter",
				       "link": "https://www.youtube.com/watch?v=yh3bQIeuZrc",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "Conical",
				       "link": "https://youtu.be/gSIi1XEtFhk",
				       "percent": 100,
				       "hz": "180hz"
			       },
			       {
				       "user": "ThanosPig",
				       "link": "https://youtu.be/WL_I4ZPgJfg",
				       "percent": 100,
				       "hz": "Mobile"
			       },
			       {
				       "user": "saturn",
				       "link": "https://www.youtube.com/watch?v=rrVHYEcOpPc",
				       "percent": 100,
				       "hz": "288hz"
			       },
			       {
				       "user": "Bluuper",
				       "link": "https://youtu.be/zR6L4YDkHs0",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "TheRealYeeter",
				       "link": "https://youtu.be/BTYkSLyirD0",
				       "percent": 100,
				       "hz": "Mobile"
			       },
			       {
				       "user": "Creatormichaelr",
				       "link": "https://youtu.be/YiT2m8Lb6ks",
				       "percent": 100,
				       "hz": "300hz"
			       },
			       {
				       "user": "piesy",
				       "link": "https://youtu.be/W-PDlK2onik",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "charlielance",
				       "link": "https://www.youtube.com/watch?v=DfWCXf8Bk1Y",
				       "percent": 100,
				       "hz": "120hz"
			       },
			       {
				       "user": "opayc",
				       "link": "https://youtu.be/skqXRm3cMec",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "Zirkitri",
				       "link": "https://www.youtube.com/watch?v=j2UYxOyU3y0",
				       "percent": 100,
				       "hz": "Mobile"
			       },
			       {
				       "user": "jToniX",
				       "link": "https://youtu.be/wt1Js275CKA",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "Zurteh",
				       "link": "https://youtu.be/p0WMdcoyt6k",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "Hixobit",
				       "link": "https://www.youtube.com/watch?v=Xlz-g3vFlVU",
				       "percent": 100,
				       "hz": "300hz"
			       },
			       {
				       "user": "Plasmic",
				       "link": "https://www.youtube.com/watch?v=8kUtEQn0vVI&feature=youtu.be",
				       "percent": 100,
				       "hz": "300hz"
			       },
			       {
				       "user": "Zexer",
				       "link": "https://www.youtube.com/watch?v=cwXrjUceSaE",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "Daxy",
				       "link": "https://youtu.be/L7bQfjukaVE",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "Tai0",
				       "link": "https://www.twitch.tv/videos/696174767",
				       "percent": 100,
				       "hz": "120hz"
			       },
			       {
				       "user": "XImaPlayerX",
				       "link": "https://youtu.be/wPxJQfYrxAQ?t=686",
				       "percent": 96,
				       "hz": "75hz"
			       },
			       {
				       "user": "MP3141",
				       "link": "https://youtu.be/_H9YY9K4st8",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
				       "user": "Dashermachine",
				       "link": "https://youtu.be/jXuslA3l9Fs?t=85",
				       "percent": 100,
				       "hz": "60hz"
			       },
			       {
				       "user": "zMarc",
				       "link": "https://youtu.be/Dj_zjZNpbwg",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "Akira Kurisu",
				       "link": "https://youtu.be/Vm691W1q72A",
				       "percent": 100,
				       "hz": "144hz"
			       },
			       {
					"user": "FrostBurn",
					"link": "https://youtu.be/Ltzt5PUijuw",
					"percent": 100,
					"hz": "144hz"
			       },
			       {
					"user": "mrbananan",
					"link": "https://www.youtube.com/watch?v=KpZJEFnOtQo&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
			       },
			       {
					"user": "InferiorPatty",
					"link": "https://www.youtube.com/watch?v=EQgJn4vQY58&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
			       },
			       {
					"user": "UNarwall",
					"link": "https://youtu.be/SQ64QLR91RMe",
					"percent": 100,
					"hz": "240hz"
			       },
			       {
					"user": "Blast",
					"link": "https://youtu.be/0JS_vHk1llE",
					"percent": 100,
					"hz": "Mobile"
			       },
			       {
					"user": "FoZard",
					"link": "https://youtu.be/WWABk59duWY",
					"percent": 100,
					"hz": "165hz"
			       },
			       {
				       "user": "Spacethug",
				       "link": "https://youtu.be/IXJXiaeMYLo",
				       "percent": 100,
				       "hz": "240hz"
			       },
			       {
				       "user": "Covieta",
				       "link": "https://youtu.be/oN8hAYBtJlI",
				       "percent": 100,
				       "hz": "144hz"
			       },
                       ],
                       "name": "Shitty Poltergeist",
                       "author": "AcropolisBoy",
                       "more": "none",
                       "id": 49472213,
                       "pass": "Free to copy",
                       "percentToQualify": 51,
                       "verificationVid": "",
                       "key": 79
                },
		/*================================================================================= */
		{
			"vids": [
				{
					"user": "amedxx2y",
					"link": "https://youtu.be/YLuPNx5xL3s",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=gEnsiTwZKdA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "justiceguy",
					"link": "https://www.youtube.com/watch?v=4hDzXQ2aF7M&t=87s",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/XLBmDGAM258",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bluuper",
					"link": "https://www.youtube.com/watch?v=mgicD6trv1A",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/Qe5UqFuJ55w",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Kanolli",
					"link": "https://www.youtube.com/watch?v=hwJydbTVAYI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "HdLink13",
					"link": "https://youtu.be/ZNhBNXyAN3o",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "TheRealYeeter",
					"link": "https://youtu.be/w13-X0NEf1Y",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Acute",
					"link": "https://www.youtube.com/watch?v=WoDZAyjV4JM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Acetolysis",
					"link": "https://youtu.be/is59OzEZnic",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "kuwushi",
					"link": "https://www.youtube.com/watch?v=IHPnIPGN4R8&t=80s",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bentai",
					"link": "https://www.youtube.com/watch?v=baUpz1AFcvY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/R1Lledqywy0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Zirkitri",
					"link": "https://youtu.be/LEvb9NoJ5Tk",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=zJ0Z6Es9dvQ",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Rigno",
					"link": "https://youtu.be/IASLbWI6aws",
					"percent": 68,
					"hz": "236hz"
				},
				{
					"user": "Emonadeo",
					"link": "https://www.youtube.com/watch?v=MB9LVXMCkYk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/Z53u79iFFMA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/cUXgG7eThtM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "StarLight722",
					"link": "https://youtu.be/sCppAt3tCVQ",
					"percent": 100,
					"hz": "Mobile"
				},
			],
			"name": "Shitty xo",
			"author": "D4M5",
			"more": "none",
			"id": 58726015,
			"pass": "694201",
			"percentToQualify": 50,
			"verificationVid": "https://www.youtube.com/watch?v=wqSDcRO4BCQ",
			"key": 80
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=2h5EX9IqWfc",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "HdLink13",
					"link": "https://youtu.be/q1QsNJcv-vM",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "FallenAresse",
					"link": "https://www.youtube.com/watch?v=mL6062zepcQ&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
                                        "user": "Fhyron06",
                                        "link": "https://www.youtube.com/watch?v=-YKuASXsK9Y",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
                                        "user": "nayf",
                                        "link": "https://youtu.be/nobiI-uyqps",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/-hsPIB5MnpM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "TH54",
					"link": "https://youtu.be/1qugombbG9Q",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=R2_yesBQ_lQ&feature=youtu.be",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/us_ZhYHGMls",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/0Pb9mmB5Yv0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://www.youtube.com/watch?v=LYpPBv3begg&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "FrostBurn",
					"link": "https://youtu.be/_PKhc20wU7I",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Ky",
					"link": "https://www.youtube.com/watch?v=6mvjrpNwdNE",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/701002051",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Xela343",
					"link": "https://www.youtube.com/watch?v=ItqicD5-r78",
					"percent": 100,
					"hz": "144hz"
				},
			],
			"name": "Shitty Kidsmoke",
			"author": "Whiliams8080 and rVlaash [Whiliams8080]",
			"more": "none",
			"id": 60487752,
			"pass": "258963",
			"percentToQualify": 58,
			"verificationVid": "https://www.youtube.com/watch?v=qnlbpIA9Zjg",
			"key": 81
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=ftLAlu6iR2s",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/yTuRCZuVOfA",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "HdLink13",
					"link": "https://youtu.be/DCd8TcM6MPE",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/eLyMH9mzxd8",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://www.youtube.com/watch?v=Dog2BHuHhwY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Frigus",
					"link": "https://www.youtube.com/watch?v=4QUH6geddoI&t",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Gloomy boy",
					"link": "https://youtu.be/HTNmjD2MF4I",
					"percent": 100,
					"hz": "Mobile"
				},
				{
                                        "user": "N1kix",
                                        "link": "https://youtu.be/q0ZmKhOgkks",
                                        "percent": 100,
                                        "hz": "120hz"
                                },
				{
                                        "user": "Pipzzzzzzz",
                                        "link": "https://youtu.be/TExRCta54GU",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "DaddyGoose",
                                        "link": "https://www.youtube.com/watch?v=s-Ms_nt1-no&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "210hz"
                                },
				{
                                        "user": "Bluuper",
                                        "link": "https://youtu.be/8p7EMknwZ_s",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
					"user": "saturn",
					"link": "https://www.youtube.com/watch?v=gxD9Rgbfs6Q",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Zshadoweye",
					"link": "https://www.youtube.com/watch?v=r19Tfdp9MWY&t=3s",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/xf2y2TWZViE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/2Hc0YNGewwA",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/fSGBbOvbPbU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/dBfxbw3R5tI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/3CBZtd22bW8",
					"percent": 72,
					"hz": "120hz"
				},
				{
					"user": "HideriGh",
					"link": "https://youtu.be/RsrNMBgMuFM",
					"percent": 70,
					"hz": "144hz"
				},
				{
					"user": "misterious",
					"link": "https://youtu.be/VQF7vDQfkAg",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/bZDmcsyIlOU",
					"percent": 100,
					"hz": "120hz"
				},
			],
			"name": "Shitty Artifice",
			"author": "Megum and more [Megum]",
			"more": "AcropolisBoy, Serpyy, ItzShuvon, MiiNi03, HeizenSS, Keleru, GDStarStorm, SoyNadie",
			"id": 58965186,
			"pass": "Free to copy",
			"percentToQualify": 66,
			"verificationVid": "https://www.youtube.com/watch?v=5UTJ5-_WQNs",
			"key": 82
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Vink",
					"link": "https://youtu.be/-GML-X8ytts",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/Vm9jvoc8gLg",
					"percent": 100,
					"hz": "144hz"
			        },
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=B1rfHuJYA0g",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Gabe",
					"link": "https://youtu.be/PKAtDeYh5t8",
					"percent": 100,
					"hz": "60hz"
				},
				{
                                        "user": "Soda",
                                        "link": "https://www.youtube.com/watch?v=vIgmQdDkcnA",
                                        "percent": 100,
                                        "hz": "75hz"
				},
				{
					"user": "Aurora",
                                        "link": "https://youtu.be/i9SBv4TiQZ4",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "Pipzzzzzzz",
                                        "link": "https://youtu.be/OjeQLpnIbkQ",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "Aiden",
                                        "link": "https://www.youtube.com/watch?v=tL9GFtiZjUE",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "RG",
                                        "link": "https://www.youtube.com/watch?v=BxaadTZkpS8",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
                                        "user": "GrimPencil16",
                                        "link": "https://youtu.be/lOHUnzTE1fE",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
					"user": "iRaily",
                                        "link": "https://youtu.be/NMzRyBxZ6j8",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "GDMeric",
                                        "link": "https://youtu.be/daF8DxZzkm4",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "saturn",
                                        "link": "https://youtu.be/lpVDS4Dk3_E",
                                        "percent": 100,
                                        "hz": "288hz"
				},
				{
					"user": "Evilperson34",
                                        "link": "https://www.youtube.com/watch?v=pqKx0X9W8r4&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "280hz"
				},
				{
					"user": "TH54",
                                        "link": "https://www.youtube.com/watch?v=LvD3tPgaWiI",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "nayf",
                                        "link": "https://youtu.be/VoF7OW54Of4",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "DaddyGoose",
                                        "link": "https://www.youtube.com/watch?v=XwE2H3fkYyU&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "210hz"
				},
				{
					"user": "Alphanetic",
                                        "link": "https://youtu.be/9ZQUanZPNBU",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "Conical",
                                        "link": "https://youtu.be/f8OMc_y2fBo",
                                        "percent": 100,
                                        "hz": "180hz"
				},
				{
					"user": "Ensanity",
                                        "link": "https://youtu.be/nSumERWB5kE",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "Moosh",
                                        "link": "https://www.youtube.com/watch?v=gLjG0WPHw5Q",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "MiniShoey",
                                        "link": "https://youtu.be/KTnpNEPeXC4",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "Bluuper",
                                        "link": "https://youtu.be/tyPFGpW2LUo",
                                        "percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "WowoGD",
                                        "link": "https://youtu.be/nGeZikUizE0",
                                        "percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/fKSodlpsINM",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Matter",
					"link": "https://youtu.be/tX_jMwTxOZo",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Baechukimchi",
					"link": "https://youtu.be/oV3IRzM1GbM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Wyaaronpc",
					"link": "https://youtu.be/16AmtuglY8U",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/9M8tzCo19Wg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/pzWrPABkhSI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "ImInquired",
					"link": "https://www.youtube.com/watch?v=6HFYNe6Nk2Y&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "HamburgerMan",
					"link": "https://www.youtube.com/watch?v=NiafnhiTFQM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Spacethug",
					"link": "https://youtu.be/UqmQXgD0wpY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Charlielance",
					"link": "https://www.youtube.com/watch?v=wcAchL5fex0",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "jToniX",
					"link": "https://youtu.be/-0OXId9NSKY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "DomanikGD",
					"link": "https://www.youtube.com/watch?v=Lwh5tzlu3lA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "VdT",
					"link": "https://youtu.be/hGX8PUb99kg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Hixobit",
					"link": "https://www.youtube.com/watch?v=oXuZuyp6sFQ&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/rYg9WdFG0nk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=Cnw2VvDXfHk&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "CavEmaN_mElviN",
					"link": "https://www.youtube.com/watch?v=HjhYyXb3Uys&list=PLAHT5vTrU-yiL3XyTFLt8XbRvYqQOXGIj&index=3",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Zexer",
					"link": "https://www.youtube.com/watch?v=BDnhFaeqSzo",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/uhaOW20AJsM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "ItzShadowMine",
					"link": "https://www.youtube.com/watch?v=CzCgr4I1MQQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/696166171",
					"percent": 100,
					"hz": "120hz"
				},
				{
  					"user": "InferiorPatty",
  					"link": "https://www.youtube.com/watch?v=t6Tbov_rsIA&feature=youtu.be",
    					"percent": 100,
    					"hz": "300hz"
				},
				{
  					"user": "arielus05",
  					"link": "https://youtu.be/WgINbN6Rq0Q",
    					"percent": 100,
    					"hz": "144hz"
				},
				{
  					"user": "XImaPlayerX",
  					"link": "https://youtu.be/wPxJQfYrxAQ?t=626",
    					"percent": 100,
    					"hz": "75hz"
				},
				{
  					"user": "Bentai",
  					"link": "https://www.youtube.com/watch?v=TP6414kRbZo&feature=youtu.be",
    					"percent": 100,
    					"hz": "300hz"
				},
				{
  					"user": "Arcturus",
  					"link": "https://youtu.be/FD6cqRxNhlo",
    					"percent": 100,
    					"hz": "300hz"
				},
				{
  					"user": "TheRealYeeter",
  					"link": "https://youtu.be/Sgo_xjL3aDE",
    					"percent": 100,
    					"hz": "Mobile"
				},
				{
  					"user": "Auspicious",
  					"link": "https://youtu.be/pVVMTTcpk2o",
    					"percent": 71,
    					"hz": "240hz"
				},
				{
					"user": "FrostBurn",
					"link": "https://youtu.be/On4HywGFh64",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=MUnAzV2M2z0",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "RageRod",
					"link": "https://www.youtube.com/watch?v=RwlDbvatpg4",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=rpkJGYbsrAQ&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Emonadeo",
					"link": "https://www.youtube.com/watch?v=RA-9zYp3xHU",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=EshMRcf5alA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/CW98S7sW-F4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Xela343",
					"link": "https://www.youtube.com/watch?v=EHOkE4sEcpg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Unecycle",
					"link": "https://www.youtube.com/watch?v=HE_czvDJ-L8",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "FoZard",
					"link": "https://youtu.be/QSUCEkZ3yFQ",
					"percent": 100,
					"hz": "165hz"
				},
                	],
			"name": "Shitty Sakupen Hell",
			"author": "AcropolisBoy [timckic]",
			"more": "none",
			"id": 49508396,
			"pass": "Free to copy",
			"percentToQualify": 50,
			"verificationVid": "https://www.youtube.com/watch?v=lDiqYSya0NA",
			"key": 83
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=wwDpiz1PPlg",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/EzdPkO6xXKI",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=cJskoN4B13E",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/Av3cZlMdgZg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "amedxx2y",
					"link": "https://youtu.be/f7JLHuotJnw",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=H-ERw_vwnkI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Kr_Flame",
					"link": "https://www.youtube.com/watch?v=dz1pGfljRoY&t=51s",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Chojang",
					"link": "https://www.youtube.com/watch?v=dz1pGfljRoY&t=51s",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "md1159",
					"link": "https://youtu.be/qqrHPVfTHyw",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Vaxer",
					"link": "https://m.youtube.com/watch?v=tZAKbxwEco4",
					"percent": 100,
					"hz": "Mobile"
				},
				{
                                        "user": "N1kix",
                                        "link": "https://youtu.be/q0ZmKhOgkks",
                                        "percent": 100,
                                        "hz": "120hz"
                                },
				{
					"user": "Bluuper",
					"link": "https://youtu.be/sZdxBcwaZOQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/ImlljAxfDsQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/DrfLJYI9NEY",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "MacJubber",
					"link": "https://youtu.be/galVWvfE3ek",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=2YAZnXi6O4s",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "StarLight722",
					"link": "https://youtu.be/Ow84p2Utrt4",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/uBNpgyClqqM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=uzFTKSXg9Pk&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Sigma",
			"author": "Megum",
			"more": "none",
			"id": 52840973,
			"pass": "167349",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=bUz7ePRVGAk",
			"key": 84
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=-TeyD0HYGVo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=Rt_aEjGLflI&t=29s",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "rMinelo",
					"link": "https://www.youtube.com/watch?v=TYRQHHUbNX8",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "iRaily",
					"link": "https://youtu.be/x-RrmyNM-Jc",
					"percent": 100,
					"hz": "Mobile"
				},
			        {
                                        "user": "sandstormy",
                                        "link": "https://www.youtube.com/watch?v=1eHfsQnK0ys&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
					"user": "md1159",
					"link": "https://youtu.be/ZLfGDEI-muI",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://youtu.be/VX9-Im9KJtg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "1qawsz",
					"link": "https://youtu.be/SYORrgel4xA",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/x-zut6LkWU4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/3rFf-HT_xD0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/bZF9o6Fsvn4",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/kpMljL5p-Lw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/l6FOyp9eDio",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "TH54",
					"link": "https://youtu.be/Xzvu2ORt89M",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Zshadoweye",
					"link": "https://www.youtube.com/watch?v=Sc-Cvi1cgYg",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/rEeKl5RHwco",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "LandonW3",
					"link": "https://youtu.be/Bg0ZggrIMd0",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/BtsKoa5rxyI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Blast",
					"link": "https://youtu.be/PnObzfVhtWs",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Ayanakodji",
					"link": "https://youtu.be/PzP6FJaMt-Q",
					"percent": 100,
					"hz": "Mobile"
				},
                        ],
			"name": "Shitty Visible Ray",
			"author": "Megum and more [Megum]",
			"more": "Segone, SkullBytes, ShadowNinja441, ShuvonIslam777, ZenrioL, Serpyy, AlexTheGS33",
			"id": 55174871,
			"pass": "042019",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=6JYh8vNm-EA",
			"key": 85
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=kdVRBcGmhhw",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://www.youtube.com/watch?v=qpIgt2C0Ma8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "azizRCL",
					"link": "https://www.youtube.com/watch?v=zitCTwRDYvo",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/aI_UIBUNPiY",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Amedxx2y",
					"link": "https://youtu.be/NBviLiRCwmU",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=rFyjOfAjQxQ",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "ZekronGD",
					"link": "https://youtu.be/WVtTHS0F6HE",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/6er76pWej7Y?t=119",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/T7d6LGeuBCg",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Gloomy boy",
					"link": "https://youtu.be/1A6eQY681y4",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Trollomggamer",
					"link": "https://youtu.be/L1JXOO3vvLc",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/6G2exZJK184",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://www.youtube.com/watch?v=I_nm9rlthsQ&feature=youtu.be",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Cailloux",
					"link": "https://www.instagram.com/tv/CCwvzYkIwFm/",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Whiteteeth",
					"link": "https://youtu.be/tVaaZRu9_EU",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Baechukimchi",
					"link": "https://www.youtube.com/watch?v=BrZngPZFlXo",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "EyeHurty",
					"link": "https://www.youtube.com/watch?v=ok3DDww-q0Q&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/oS6-mlax2D4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/OxvKS75SX1E",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/cUIKl70NgfE",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "GrimPencil16",
					"link": "https://youtu.be/GVt3gMhUYm8",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "ThanosPig",
					"link": "https://youtu.be/MhothPmCAic",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Veedio",
					"link": "https://www.youtube.com/watch?v=7pT2zkJKfpM&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "chogath",
					"link": "https://youtu.be/efeyMsqRU58",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Hixobit",
					"link": "https://www.youtube.com/watch?v=rDSRRLsel80&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/zkT-dht86Zw",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Acute",
					"link": "https://www.youtube.com/watch?v=fB4uRVoecMk",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=obPklestmtk&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Makov",
					"link": "https://youtu.be/eqXSjgmxTuA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Zexer",
					"link": "https://www.youtube.com/watch?v=MoCZIpRzWnM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "X99",
					"link": "https://youtu.be/-zC5d6VzS-w",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XImaPlayerX",
					"link": "https://youtu.be/wPxJQfYrxAQ?t=515",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "GreenLemon",
					"link": "https://youtu.be/xcmjAn8Re40",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Dashermachine",
					"link": "https://youtu.be/jXuslA3l9Fs?t=172",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Zshadoweye",
					"link": "https://www.youtube.com/watch?v=LwNAI4W3IsY",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "vlubz",
					"link": "https://youtu.be/DwuFiYUtKV8",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Just_Lemon",
					"link": "https://www.youtube.com/watch?v=a48R6x6DdAc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/w5fKxC46m8o",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/_4mKMvuPxhs",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "BOSTONTHEKIDRS",
					"link": "https://youtu.be/psxnx_Wk0Ac",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "GoldenPlayz",
					"link": "https://www.youtube.com/watch?v=TLPhTxpbJZY",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Wadur",
					"link": "https://www.youtube.com/watch?v=t2A8kw7YhsE&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Spacethug",
					"link": "https://youtu.be/uGDFNZ5kf-g",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Lucid Nightmares",
			"author": "ShadowNinja441 and more [ShadowNinja441]",
			"more": "AcropolisBoy, ItzShuvon, deleitor11, SoyNadie, AlexTheGS33, ThePhoenixGHG, Serpyy",
			"id": 55566910,
			"pass": "243759",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=YkGrbj0vucY",
			"key": 86
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "md1159",
					"link": "https://youtu.be/c0Yd4c9pRPo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=uybwDY8Tuv4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/U9mcizYMxYY",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/qRDjlluk8_Q",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=98IMiHK0LMU&t=5s",
					"percent": 100,
					"hz": "75hz"
				},
			],
			"name": "Shitty Heartbeat",
			"author": "Serpyy",
			"more": "none",
			"id": 61062560,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=CwmVzTRcfGI",
			"key": 87
		},
		/*=================================================================================*/
				{
			"vids": [
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=XNeQQgGKc94",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "AcropolisBoy",
					"link": "https://www.youtube.com/watch?v=Nq5IIUnlGFE",
					"percent": 64,
					"hz": "240hz"
				},
				{
					"user": "TheRealSiel07",
					"link": "https://youtu.be/npnvbRSlKGI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=HmxVeP9DriM",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "GDPentol",
					"link": "https://youtu.be/pCcVjQaJyi8",
					"percent": 73,
					"hz": "165hz"
				},
				{
					"user": "md1159",
					"link": "https://youtu.be/-_QaK0H1FMk",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/qLvxTjKJqaU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bluuper",
					"link": "https://www.youtube.com/watch?v=ptXfKIhg60I",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Cyns",
					"link": "https://youtu.be/CmyvzpRW8Xs",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Tbocelot10",
					"link": "https://youtu.be/dQN40dm7znk",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/01_FIYWEck8",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/ljE11r2f29g",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://www.youtube.com/watch?v=1lPH9LfiZxE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "FallenAresse",
					"link": "https://www.youtube.com/watch?v=Oka_l7NMaNc&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/zlEghzNGEvE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/FyilPamENNs",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Zexer",
					"link": "https://www.youtube.com/watch?v=s7uXnDEyO9k",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bangaled",
					"link": "https://youtu.be/OY7avW4RMjM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GreenLemon",
					"link": "https://youtu.be/LTaFwmAh1iM",
					"percent": 78,
					"hz": "240hz"
				},
				{
					"user": "Blast",
					"link": "https://youtu.be/BQA_uZihmek",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/Ty0wq9TZkYs",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/1E0UAwU02nA",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=9lR8LAlMWSk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=twdIxmhlfSk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Emonadeo",
					"link": "https://www.youtube.com/watch?v=jmqFrg5WYmY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/IzN7qRVECZg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "1987Evan",
					"link": "https://youtu.be/ElZ8kprFUoE",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "StarLight772",
					"link": "https://youtu.be/ElZ8kprFUoE",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Dashermachine",
					"link": "https://youtu.be/dceQD7-yp3c?t=116",
					"percent": 59,
					"hz": "60hz"
				},
				{
					"user": "zriv",
					"link": "https://youtu.be/fp6b_5ucDvo",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=HtD3uB_T5_4&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
			],
			"name": "Shitty Mujigae",
			"author": "Serpyy",
			"more": "none",
			"id": 50594877,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://youtu.be/qLvxTjKJqaU",
			"key": 88
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=jCqe2PfUpFk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/yKw4uOXHXl0",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/BB9MziRw8J8",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "FallenAresse",
					"link": "https://www.youtube.com/watch?v=4dtrirgNZLU&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/6er76pWej7Y",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/WVK2Ut8GtSM",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Plastornious",
					"link": "https://youtu.be/w--JFA668Z4",
					"percent": 65,
					"hz": "75hz"
				},
				{
					"user": "Acidius",
					"link": "https://www.youtube.com/watch?v=9Xfve9J8n-k",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "aurora",
					"link": "https://youtu.be/Wfx9XRmKhjg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "vekarzi",
					"link": "https://youtu.be/J0Gsc8obSZk",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "GDMeric",
					"link": "https://www.youtube.com/watch?v=oSgPQ7szFFk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Cailloux",
					"link": "https://www.instagram.com/tv/CCEpyK_IXyF/",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GdWaaab",
					"link": "https://youtu.be/LCwud4FcxUw",
					"percent": 73,
					"hz": "Mobile"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/PIh-SXLd6bU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Wyaaronpc",
					"link": "https://youtu.be/Tj-7UNnEFxE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/QBky9dJEi-M",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "HdLink13",
					"link": "https://youtu.be/V-6zytjrH-k",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=G42yPg698L0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "TheRealYeeter",
					"link": "https://youtu.be/DdeONZRhWMQ",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Veedio",
					"link": "https://www.youtube.com/watch?v=7pT2zkJKfpM&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "GDWish",
					"link": "https://youtu.be/7Dk_CInJSnw",
					"percent": 82,
					"hz": "300hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/7hfk-VcfqLw",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/UKrO9AyhYqE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/2wlfKZdjnCM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "chogath",
					"link": "https://youtu.be/bZd9O5TtTKc?t=251",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Praerius",
					"link": "https://www.youtube.com/watch?v=gb9vVGyhZtg&lc=UgzRqOrl3vzF5iRFUvx4AaABAg",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Acute",
					"link": "https://www.youtube.com/watch?v=CwlZUv1BTQQ",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Poptart",
					"link": "https://youtu.be/csfVLGbt4xM?t=2268",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/NUstpvkvmLw",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "jToniX",
					"link": "https://youtu.be/VhV0n5IvKGE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=01AEbV-x9Ns&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/696155397",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "XImaPlayerX",
					"link": "https://youtu.be/wPxJQfYrxAQ?t=404",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "lvcxs",
					"link": "https://youtu.be/mmdUlPgsxMU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/EKh7QG5d81M",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Zirkitri",
					"link": "https://youtu.be/1TtKZehtsa8",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "InferiorPatty",
					"link": "https://www.youtube.com/watch?v=srQdFz0fJVc&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Yaev",
					"link": "https://www.youtube.com/watch?v=NrZQD7Pt2b0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/0V-UatW68wo",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "zriv",
					"link": "https://youtu.be/RiBG6ir-Bgk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "DoubleSsymbol",
					"link": "https://www.youtube.com/watch?v=H96n9NmVWOY",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "FrostBurn",
					"link": "https://youtu.be/20zWbfjrfGE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/JS3x5YXRYBk",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Blast",
					"link": "https://youtu.be/AODiNj9Y9g0",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/xmJVeGdHSto",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "StarLight772",
					"link": "https://www.youtube.com/watch?v=Z1ZcTvp5ITs&feature=youtu.be",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "michael1604",
					"link": "https://youtu.be/2JbxhxxJByM",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "ShDwGhost",
					"link": "https://www.twitch.tv/videos/699763922",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Dashermachine",
					"link": "https://youtu.be/dceQD7-yp3c",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Xela343",
					"link": "https://www.youtube.com/watch?v=fKYxj-rNH8M",
					"percent": 100,
					"hz": "1440hz"
				},
				{
					"user": "Covieta",
					"link": "https://youtu.be/qK2zTmwxJdk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "SlicedBred",
					"link": "https://www.youtube.com/watch?v=8DFCAweo_qs&feature=youtu.be",
					"percent": 100,
					"hz": "165hz"
				},
			],
			"name": "Shitty Ithacropolis",
			"author": "Deleitor11",
			"more": "none",
			"id": 57700269,
			"pass": "101825",
			"percentToQualify": 58,
			"verificationVid": "https://www.youtube.com/watch?v=QBky9dJEi-M",
			"key": 89
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "Whiliams8080",
					"link": "https://www.youtube.com/watch?v=aFZsevhsvvQ",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=-GGnlYKjBL8&t=11s",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Aassbll",
					"link": "https://www.youtube.com/watch?v=K9HpySLTwpI",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/GCBDN97J-fs",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Chojang",
					"link": "https://youtu.be/a8waYvacVIU",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "eafan0",
					"link": "https://youtu.be/Wevu1LVb9nA",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "md1159",
					"link": "https://www.youtube.com/watch?v=Z10p-Pp71Uo&feature=youtu.be",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Fhyron06",
					"link": "https://youtu.be/BevJA_JUH6w",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Bluuper",
					"link": "https://www.youtube.com/watch?v=Z6JrT390Ygc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=BxaadTZkpS8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/EbdE7ADS6Ns",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "GDMeric",
					"link": "https://youtu.be/QfKYFFO7IFk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "FallenAresse",
					"link": "https://www.youtube.com/watch?v=4_W3lWqGVVg&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/bZF9o6Fsvn4",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=WYp99ObkxzE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/zQ9V53_C9y0",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/jamoJty7m34",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/LJLHyhi4fu4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/08MaIzumNr4",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=EXq1gmqpY-s&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Baechukimchi",
					"link": "https://www.youtube.com/watch?v=PRA0i8YMWfE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "XImaPlayerX",
					"link": "https://youtu.be/wPxJQfYrxAQ?t=261",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/OvJOotsVwl8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "mrbananan",
					"link": "https://www.youtube.com/watch?v=M2G3hDIlZHE&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Emonadeo",
					"link": "https://www.youtube.com/watch?v=iFQDdwdmUWs",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/1PN4wvOdwYI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Tai0",
					"link": "https://youtu.be/foHYoN4X6lc",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Unecycle",
					"link": "https://www.youtube.com/watch?v=yt5Qtg0TiK8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Xela343",
					"link": "https://www.youtube.com/watch?v=iPIpD75-GUM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Just_Lemon",
					"link": "https://www.youtube.com/watch?v=4dvF4JCiMA4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "zMarc",
					"link": "https://youtu.be/3Wl4sncUzs4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "IIEliteRainII",
					"link": "https://youtu.be/kW1Tq8HTHQ8",
					"percent": 100,
					"hz": "75hz"
				},
			],
			"name": "Shitty Paroxysm",
			"author": "Megum",
			"more": "none",
			"id": 46950888,
			"pass": "135086",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=mBa4Q1PFzN4",
			"key": 90
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=PtVpcRL29jA",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/P0y3gXK4BgM",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/fmZn_2QcMbs",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "md1159",
					"link": "https://youtu.be/J_KTjFvU4hs",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Frigus",
					"link": "https://www.youtube.com/watch?v=m4FgrWAbJl0",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "HdLink13",
					"link": "https://youtu.be/O14ROgcU6oE",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://www.youtube.com/watch?v=Kh3UbxWuLmQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "ZekronGD",
					"link": "https://youtu.be/4VCqlJiYDcg",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Acidius",
					"link": "https://www.youtube.com/watch?v=f5YT15HAauo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/l6v4zza1XOc",
					"percent": 100,
					"hz": "144hz"
				},
				{
                                        "user": "Soda",
                                        "link": "https://www.youtube.com/watch?v=Y-R5ZXJ31HE",
                                        "percent": 100,
                                        "hz": "75hz"
                                },
			        {
                                       "user": "mestupid",
                                        "link": "https://youtu.be/HbXBNU50QLc",
                                        "percent": 100,
                                        "hz": "288hz"
                                },
			        {
                                        "user": "Tonyearl",
                                        "link": "https://youtu.be/ytQAAfex6HM",
                                        "percent": 100,
                                        "hz": "300hz"
                                },
			        {
					"user": "saturn",
					"link": "https://youtu.be/HG9F0zM8fBU",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Questionblockg",
					"link": "https://youtu.be/7PeIJ5zkLdU",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=wuoDmdY2fB8",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Batle",
					"link": "https://youtu.be/ZUH1_v5fXzo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/mtvdpLSz4tA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Deados35",
					"link": "https://youtu.be/wkX0a_Xp830",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "jToniX",
					"link": "https://youtu.be/pUKdDurrj-o",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Acute",
					"link": "https://www.youtube.com/watch?v=OECx6eow-ww",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/eooNdOezXSQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Batle",
					"link": "https://youtu.be/ZUH1_v5fXzo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/VYS5SVGRCyQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "HideriGH",
					"link": "https://youtu.be/9sappwgSJ1U",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "IIEliteRainII",
					"link": "https://youtu.be/ikjztx5j-hM",
					"percent": 100,
					"hz": "75hz"
				},
			],
			"name": "Shitty SPL",
			"author": "Serpyy",
			"more": "none",
			"id": 56489174,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=s-MQYRZdPQw",
			"key": 91
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "rVlaash",
					"link": "https://youtu.be/xGnPhKHel5Y",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Soda",
					"link": "https://youtu.be/79HNFIaVQEg",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "md1159",
					"link": "https://youtu.be/sHVgN7ScNjA",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://www.youtube.com/watch?v=_Ksd6sKlD4g&t=234s",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "HdLink13",
					"link": "https://youtu.be/zJvpNKM3PKM",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Gloomy boy",
					"link": "https://youtu.be/0Hck6ra7Oes",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Frigus",
					"link": "https://www.youtube.com/watch?v=qHRO5WU2n6M",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Fhyron06",
					"link": "https://youtu.be/eqsVD2-AcVg",
					"percent": 100,
					"hz": "240hz"
				},
					{
					"user": "Bluuper",
					"link": "https://youtu.be/gml6nDgFCzA",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Tonyearl",
					"link": "https://youtu.be/7RthPG51cAc",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Dist3nd",
					"link": "https://youtu.be/02tQuo6ouAk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/bZF9o6Fsvn4",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Questionblockg",
					"link": "https://youtu.be/GkqUVm7z2JA",
					"percent": 69,
					"hz": "Mobile"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/qjLpmyDU_7A",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/g_l8_vTIkhI",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Deados35",
					"link": "https://youtu.be/PvdEbLQ45o0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=uvyCTM10muo",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Wrandom Stuff",
					"link": "https://www.youtube.com/watch?v=-X1I6Gjbq2Q",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Makov",
					"link": "https://youtu.be/pYX3LsEkiy4",
					"percent": 59,
					"hz": "240hz"
				},
				{
					"user": "MacJubber",
					"link": "https://youtu.be/kzcWFAWInYg",
					"percent": 98,
					"hz": "300hz"
				},
				{
					"user": "Acetolysis",
					"link": "https://www.youtube.com/watch?v=cMrDgA1K1wg&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "UNarwall",
					"link": "https://www.youtube.com/watch?v=aMe44ql8iGo&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/RHvX6k1gCSM",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "IlEliteRainlI",
					"link": "https://www.youtube.com/watch?v=JwaEpicfqbM&feature=youtu.be",
					"percent": 100,
					"hz": "75hz"
				},
			],
			"name": "Shitty Esencia",
			"author": "Megum",
			"more": "none",
			"id": 57833596,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=0FM56f4CdH8",
			"key": 92
		},
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "amedxx2y",
					"link": "https://youtu.be/hjFliXl-6TQ",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "GdWaaab",
					"link": "https://youtu.be/C6YXuAQ-_kE",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "rVlaash",
					"link": "https://www.youtube.com/watch?v=FqeX9LNJxT8",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Soda",
					"link": "https://www.youtube.com/watch?v=FxLFkrDLCzc",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "md1159",
					"link": "https://youtu.be/vRfG9r8KajA",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "XanPlayzGamez",
					"link": "https://youtu.be/KORCAwATJcE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Vink",
					"link": "https://youtu.be/ET4j_NTb8Yc",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "gdaquasS",
					"link": "https://youtu.be/NYRPtIcyJak",
					"percent": 60,
					"hz": "60hz"
				},
				{
					"user": "HdLink13",
					"link": "https://youtu.be/7J8ObT025WI",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "GDPentol",
					"link": "https://www.youtube.com/watch?v=HpWbtfsutxU&feature=youtu.be",
					"percent": 58,
					"hz": "240hz"
				},
				{
					"user": "TheRealSiel07",
					"link": "https://youtu.be/tpFya8NcgVY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "PriUsGD",
					"link": "https://youtu.be/foDr8ieml08",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "qqfa",
					"link": "https://www.youtube.com/watch?v=fycJloCpOOA",
					"percent": 100,
					"hz": "144hz"
				},
			        {
                                        "user": "Geometry Dash PJH",
                                        "link": "https://youtu.be/P9JoQ7bysXc",
                                        "percent": 58,
                                        "hz": "Mobile"
                                },
				{
                                        "user": "monstergamer546",
                                        "link": "https://youtu.be/sMCwOGl1kfs",
                                        "percent": 100,
                                        "hz": "Mobile"
                                },
				{
                                        "user": "Fhyron06",
                                        "link": "https://www.youtube.com/watch?v=ian0tQvmEjs",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "Pisop",
                                        "link": "https://youtu.be/mArriMNCVVk",
                                        "percent": 72,
                                        "hz": "Mobile"
                                },
				{
                                        "user": "N1kix",
                                        "link": "https://youtu.be/scBAAvYTX6E",
                                        "percent": 100,
                                        "hz": "180hz"
                                },
				{
                                        "user": "iRaily",
                                        "link": "https://youtu.be/CYZ6tGidAIg",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
					"user": "Kr_Flame",
					"link": "https://youtu.be/INVA15tJ_b0",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Plastornious",
					"link": "https://youtu.be/7dd7wKwlrw8",
					"percent": 88,
					"hz": "75hz"
				},
				{
					"user": "Acidius",
					"link": "https://www.youtube.com/watch?v=5nX268ynpI4&feature=youtu.be",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Redjohnboy",
					"link": "https://youtu.be/mqHd-7CePpg",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Rigno",
					"link": "https://youtu.be/i08XJjvIv6A",
					"percent": 60,
					"hz": "236hz"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/dGHrLzuxtrI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "MythicalTG",
					"link": "https://youtu.be/raidI8z1Ayo",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/C945aVMPbsM",
					"percent": 100,
					"hz": "240hz"
				},
				{
                                        "user": "Matter",
                                        "link": "https://www.youtube.com/watch?v=aoAddEO5Luo",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
                                        "user": "Baechukimchi",
                                        "link": "https://www.youtube.com/watch?v=CZZe93qyakE",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
                                        "user": "GDmeric",
                                        "link": "https://youtu.be/g9SIz5L7yVs",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
                                        "user": "Tbocelot10",
                                        "link": "https://youtu.be/hx6cNk4Xi54",
                                        "percent": 100,
                                        "hz": "60hz"
                                },
				{
                                        "user": "Tonyearl",
                                        "link": "https://youtu.be/L0DywESoC58",
                                        "percent": 100,
                                        "hz": "300hz"
                                },
				{
                                        "user": "EyeHurty",
                                        "link": "https://www.youtube.com/watch?v=Kfsl9Wwrm7k&feature=youtu.be",
                                        "percent": 100,
                                        "hz": "288hz"
                                },
				{
                                        "user": "Ensanity",
                                        "link": "https://youtu.be/CYTwR8ulkOg",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
					"user": "Tril",
					"link": "https://youtu.be/LYyVuNf3vkU",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Questionblockg",
					"link": "https://youtu.be/LcswALS2uho",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Veedio",
					"link": "https://youtu.be/CMs9GZF1lQ8",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Deados35",
					"link": "https://youtu.be/5dfTaMZb9pc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Zirkitri",
					"link": "https://youtu.be/vJm--cOIAO4",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/GqOgRYZ18b4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Renar333",
					"link": "https://www.youtube.com/watch?v=Wx4B2yto2WM&feature=youtu.be",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "DomanikGD",
					"link": "https://www.youtube.com/watch?v=cWx1_Bjjyw4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "TH54",
					"link": "https://www.youtube.com/watch?v=900jdAG7Bvs",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/8qjQ6jlsb-M",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "opayc",
					"link": "https://youtu.be/8qjQ6jlsb-M",
					"percent": 92,
					"hz": "240hz"
				},
				{
					"user": "jToniX",
					"link": "https://youtu.be/L6h_23zAqvI",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Dashermachine",
					"link": "https://youtu.be/jY4nmfkf5Yw?t=246",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Zurteh",
					"link": "https://youtu.be/2UaNhn_W_BQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Makov",
					"link": "https://youtu.be/SMgeOWSSJOw",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/MWcXWOfMdi0",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Poptart",
					"link": "https://youtu.be/oXGPMHw7cmA?t=2873",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Acute",
					"link": "https://m.youtube.com/watch?v=HnTIzGuyLkw",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/696141063",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Zshadoweye",
					"link": "https://www.youtube.com/watch?v=zIIXYCABWJY",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "XImaPlayerX",
					"link": "https://youtu.be/wPxJQfYrxAQ?t=72",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "JOR_DEN",
					"link": "https://www.youtube.com/watch?v=Ci6BMU5At2s",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "TheRealYeeter",
					"link": "https://youtu.be/LX5AtbSHVRA",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "InferiorPatty",
					"link": "https://www.youtube.com/watch?v=oOFTa2DcscE&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=XKbxjrb0xPk&feature=youtu.be",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Yaev",
					"link": "https://youtu.be/c3GId7GN2mQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "FrostBurn",
					"link": "https://youtu.be/56Y1P-pN6Gg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "StarLight722",
					"link": "https://youtu.be/35C3Jp0EjtI",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Acetolysis",
					"link": "https://youtu.be/lFiLMHIMILc",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Wadur",
					"link": "https://youtu.be/kCXT8PzpkVQ",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Rigno",
					"link": "https://youtu.be/WnvJ3dzkrD8",
					"percent": 74,
					"hz": "236hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/r3nGTltia6Y",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Quetzal",
					"link": "https://youtu.be/A8Rn7xzXil4",
					"percent": 58,
					"hz": "Mobile"
				},
				{
					"user": "Reimii",
					"link": "https://youtu.be/rRxJ6zJWhRM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "IIEliteRainII",
					"link": "https://youtu.be/tpn6O696W-w",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Jupiin",
					"link": "https://youtu.be/zFocGFVBa-M",
					"percent": 57,
					"hz": "60hz"
				},
				{
					"user": "Wave",
					"link": "https://youtu.be/2Yu0clanNCw",
					"percent": 74,
					"hz": "60hz"
				},
				{
					"user": "zriv",
					"link": "https://youtu.be/IaHfKNOaw7o",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Nebula",
					"link": "https://youtu.be/ciHEZxxQyxc",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "zekothewolf",
					"link": "https://www.youtube.com/watch?v=sDz2O4XIu0g",
					"percent": 100,
					"hz": "144hz"
				},
                        ],
			"name": "Shitty Killerzone",
			"author": "Acropolisboy",
			"more": "none",
			"id": 61583214,
			"pass": "Free to copy",
			"percentToQualify": 57,
			"verificationVid": "https://www.youtube.com/watch?v=6GQliYTw6hQ",
			"key": 93
		},
		/*=================================================================================*/
		{
			"vids": [
				{
                                        "user": "iRaily",
                                        "link": "https://youtu.be/7MQ-JWMmlnM",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
                                        "user": "Aassbll",
                                        "link": "https://youtu.be/aVBLi9HEVuk",
                                        "percent": 100,
                                        "hz": "60hz"
                                },
				{
                                        "user": "Fhyron06",
                                        "link": "https://www.youtube.com/watch?v=SjbnUb-4Tvs",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "Soda",
                                        "link": "https://youtu.be/KI76aZQQZ7E",
                                        "percent": 100,
                                        "hz": "75hz"
                                },
				{
                                        "user": "HdLink13",
                                        "link": "https://youtu.be/LvZJ7Y0aygI",
                                        "percent": 100,
                                        "hz": "60hz"
                                },
				{
                                        "user": "justiceguy",
                                        "link": "https://www.youtube.com/watch?v=cQQ8N3vt5IM",
                                        "percent": 100,
                                        "hz": "60hz"
                                },
				{
                                        "user": "SaTang",
                                        "link": "https://youtu.be/mbvdVUIf7e4",
                                        "percent": 100,
                                        "hz": "60hz"
                                },
				{
                                        "user": "FallenAresse",
                                        "link": "https://youtu.be/BrQ59xNfFL4",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "XanPlayzGamez",
                                        "link": "https://youtu.be/JXqpT6V5ZA0",
                                        "percent": 100,
                                        "hz": "144hz"
                                },
				{
                                        "user": "GDTeaBag",
                                        "link": "https://youtu.be/x_twWtlkzvA?t=2364",
                                        "percent": 100,
                                        "hz": "240hz"
                                },
				{
                                        "user": "PotatoManPlays",
                                        "link": "https://youtu.be/DYNm93S7SL0",
                                        "percent": 100,
                                        "hz": "60hz"
                                },
				{
					"user": "Vink",
					"link": "https://youtu.be/8T9N33VYHhk",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "N1kix",
					"link": "https://youtu.be/scBAAvYTX6E",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "ZekronGD",
					"link": "https://youtu.be/2jgviI1NFcg",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "monstergamer546",
					"link": "https://youtu.be/_89RPUYYETg",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Amedxx2y",
					"link": "https://youtu.be/noTfmwK4LG8",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Wekil",
					"link": "https://www.youtube.com/watch?v=mvPEiJsk93o",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Kr_Flame",
					"link": "https://youtu.be/k38AS0vYIKA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Gloomy boy",
					"link": "https://youtu.be/LtspX8XCWmc",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Bluuper",
					"link": "https://youtu.be/Qkb7VB5DdHs",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Redjohnboy",
					"link": "https://youtu.be/-HKnrwFrN44",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Surpl3x",
					"link": "https://youtu.be/O8az1oj7xDs",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Wave",
					"link": "https://youtu.be/XbhNzXA2Bvw",
					"percent": 94,
					"hz": "75hz"
				},
				{
					"user": "Rigno",
					"link": "https://youtu.be/Eo2XPGolIvQ",
					"percent": 100,
					"hz": "236hz"
				},
				{
					"user": "aurora",
					"link": "https://youtu.be/ZPD9eZEjAnM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MythicalTG",
					"link": "https://youtu.be/7Y12fJwFAj8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "nayf",
					"link": "https://youtu.be/6QTI6IrXlfM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Matter",
					"link": "https://www.youtube.com/watch?v=84oBuc80KyM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "GDMeric",
					"link": "https://www.youtube.com/watch?v=oS_09W2Elv4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "saturn",
					"link": "https://youtu.be/5QYSzf0zJbI",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Tonyearl",
					"link": "https://youtu.be/TsD9HZqjbuk",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Tbocelot10",
					"link": "https://youtu.be/WyPkHC1FFA0",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Conical",
					"link": "https://youtu.be/TlTdGlNI_PQ",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Baechukimchi",
					"link": "https://www.youtube.com/watch?v=1XgCxp3v92c",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "HamburgerMan",
					"link": "https://www.youtube.com/watch?v=EEaBiyKKo4M",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "WowoGD",
					"link": "https://youtu.be/XemuyjYjEp0",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Kanolli",
					"link": "https://www.youtube.com/watch?v=MNO1AF_pzrA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "EyeHurty",
					"link": "https://www.youtube.com/watch?v=8OMg6O-AuLI&feature=youtu.be",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "Gherkin",
					"link": "https://youtu.be/aqHns_dDAVo",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Ensanity",
					"link": "https://youtu.be/VKUHNn3j6y0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "xBlur",
					"link": "https://youtu.be/ILC6gIhv-nQ",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "MiniShoey",
					"link": "https://youtu.be/zByFP8ckyPE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Dist3nd",
					"link": "https://youtu.be/sY1srPp90Tk",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Creatormichaelr",
					"link": "https://youtu.be/cofNUL6d2zk",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "ThanosPig",
					"link": "https://youtu.be/hQiGDPxtnss",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Tril",
					"link": "https://youtu.be/ZJnr5WXKD88",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "TH54",
					"link": "https://youtu.be/FwzbSstJmpM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Questionblockg",
					"link": "https://youtu.be/iVCkYIaQ0PA",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Wyaaronpc",
					"link": "https://youtu.be/lLQ05a-q7ZEA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "ShDwGhost",
					"link": "https://youtu.be/5f-DSUJLzr0",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "TheRealYeeter",
					"link": "https://youtu.be/Xs0xlbtTG6E",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "piesy",
					"link": "https://youtu.be/N_d8aVh0wv4",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Veedio",
					"link": "https://www.youtube.com/watch?v=7pT2zkJKfpM&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Fwin",
					"link": "https://www.youtube.com/watch?v=Vm-LTDhduLo",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Deados35",
					"link": "https://youtu.be/eBXo7pQGDA4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Dashermachine",
					"link": "https://www.youtube.com/watch?v=CZ1vRnaUvi0",
					"percent": 100,
                                        "hz": "60hz"
				},
				{
					"user": "jToniX",
					"link": "https://youtu.be/pfLX0hSslwI",
					"percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "Makov",
					"link": "https://www.youtube.com/watch?v=xSFxJRUvLck",
					"percent": 100,
                                        "hz": "240hz"
				},
				{
					"user": "Hxdra",
					"link": "https://www.youtube.com/watch?v=xSFxJRUvLck",
					"percent": 100,
                                        "hz": "300hz"
				},
				{
					"user": "MP3141",
					"link": "https://youtu.be/3Oobg87Es10",
					"percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "DomanikGD",
					"link": "https://www.youtube.com/watch?v=qN7M-EaiBrg",
					"percent": 100,
                                        "hz": "144hz"
				},
				{
					"user": "Renar333",
					"link": "https://youtu.be/JdPb70I1-ZU",
					"percent": 100,
                                        "hz": "120hz"
				},
				{
					"user": "Hulunn",
					"link": "https://www.youtube.com/watch?v=Pk3bVbLHuQs",
					"percent": 100,
                                        "hz": "300hz"
				},
				{
					"user": "Zurteh",
					"link": "https://youtu.be/VczUJLp6lJ4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Hixobit",
					"link": "https://www.youtube.com/watch?v=ObspBu1j-u8&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Acute",
					"link": "https://www.youtube.com/watch?v=Ge8XIh_Bp10",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Poptart",
					"link": "https://youtu.be/cxsJHtmktjM",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Mattbott321",
					"link": "https://youtu.be/72cY03-ntO8",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "zArctic",
					"link": "https://www.youtube.com/watch?v=32oLBDZ5gNg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Daxy",
					"link": "https://youtu.be/luR8zJ_Z7L0",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bangaled",
					"link": "https://youtu.be/j8YVJczaZYM",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Acetolysis",
					"link": "https://youtu.be/5QEkCCvJjIM",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "TFIBB",
					"link": "https://www.youtube.com/watch?v=n-U9_OOFLLg",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Plasmic",
					"link": "https://www.youtube.com/watch?v=EFsI54yVFIU&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Zexer",
					"link": "https://www.youtube.com/watch?v=48cPPMReokU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Bladerxial",
					"link": "https://www.youtube.com/watch?v=7OPZIRcW1nA",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Arcturus",
					"link": "https://youtu.be/ENt6vu-VTD8",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Zshadoweye",
					"link": "https://www.youtube.com/watch?v=C8LsRRsVveA",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "ItzRuPea",
					"link": "https://www.youtube.com/watch?v=GwzqVf_AHsM&t=1s",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "randomguy555",
					"link": "https://youtu.be/WlJ9QImu4tA",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "InferiorPatty",
					"link": "https://www.youtube.com/watch?v=bA_TK50H2m0&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "mrbananan",
					"link": "https://www.youtube.com/watch?v=NZ55MsQtqOY&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Nevise",
					"link": "https://youtu.be/fQALW1PGVfA",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "suseJRG",
					"link": "https://youtu.be/fQALW1PGVfA",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Tai0",
					"link": "https://www.twitch.tv/videos/696130183",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "CoolCodin",
					"link": "https://youtu.be/xx6_dpruLKs",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Yaev",
					"link": "https://www.youtube.com/watch?v=cFFH3Ot_UHo",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Zirkitri",
					"link": "https://youtu.be/z9vrpBBMOuk",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "XImaPlayerX",
					"link": "https://youtu.be/wPxJQfYrxAQ",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Yharon",
					"link": "https://www.youtube.com/watch?v=KUFgb3_twC8",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Migel",
					"link": "https://www.youtube.com/watch?v=Ef3w-2awgCM",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Arctic",
					"link": "https://youtu.be/m_VQaticFg8",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "RG",
					"link": "https://www.youtube.com/watch?v=9lR8LAlMWSk",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Th13teen",
					"link": "https://www.youtube.com/watch?v=7ac9DgQjh5I&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "JOR_DEN",
					"link": "https://www.youtube.com/watch?v=9Zrq6phMW64",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "Gdmyst1cz",
					"link": "https://youtu.be/D--zR4FUX6Q",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Wadur",
					"link": "https://youtu.be/tAgz4LhXbVQ",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "FrostBurn",
					"link": "https://youtu.be/gRpGrppsGsE",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "nIleum",
					"link": "https://www.youtube.com/watch?v=ReiwvmDFOXU&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "Bleamer",
					"link": "https://www.youtube.com/watch?v=pBp998fr8As",
					"percent": 100,
					"hz": "288hz"
				},
				{
					"user": "StarLight722",
					"link": "https://youtu.be/7GW3lRWHlu4",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "KriSsi",
					"link": "https://youtu.be/3sHRb8Q_STc",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Blast",
					"link": "https://youtu.be/afnk0uvbd6c",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Jah",
					"link": "https://www.youtube.com/watch?v=DBDRF-jwVvU",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Emonadeo",
					"link": "https://www.youtube.com/watch?v=KfXyAjRrGrY",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "UNarwall",
					"link": "https://youtu.be/MfNQvbQ4SmI",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "1987Evan",
					"link": "https://youtu.be/bWJFa5aHHQM",
					"percent": 100,
					"hz": "180hz"
				},
				{
					"user": "Xela343",
					"link": "https://www.youtube.com/watch?v=TkvsrcdpoCg",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "Just_Lemon",
					"link": "https://www.youtube.com/watch?v=gjUMKqoCw3c",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "IIEliteRainII",
					"link": "https://youtu.be/hSsSlc8aKwM",
					"percent": 100,
					"hz": "75hz"
				},
				{
					"user": "RussianKazoo",
					"link": "https://youtu.be/mlZtzojHGH4",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "LeoDeluxe",
					"link": "https://www.youtube.com/watch?v=Z37dJFoPEhU",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "Julpiin",
					"link": "https://youtu.be/i1bNqnNbZpk",
					"percent": 75,
					"hz": "60hz"
				},
				{
					"user": "Nedgie",
					"link": "https://youtu.be/iDL8jV4glUc",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "TheRealH22",
					"link": "https://youtu.be/jDPUU7Vlia8",
					"percent": 100,
					"hz": "280hz"
				},
				{
					"user": "bluey",
					"link": "https://youtu.be/0nuCfAT8jcE",
					"percent": 100,
					"hz": "240hz"
				},
				{
					"user": "DerpOverlord",
					"link": "https://www.reddit.com/r/geometrydash/comments/gyjlnc/4th_poopy_level_of_the_day/?utm_source=share&utm_medium=ios_app&utm_name=iossmf",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "avrg",
					"link": "https://youtu.be/M5fND_38LdU",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Reimii",
					"link": "https://youtu.be/tmpANtEP8cQ",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "arielus05",
					"link": "https://youtu.be/LIrtMScegBc",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "Forz1ple",
					"link": "https://www.youtube.com/watch?v=49ftMDWFzBA&feature=youtu.be",
					"percent": 100,
					"hz": "72hz"
				},
				{
					"user": "Kind1e",
					"link": "https://vimeo.com/445421003",
					"percent": 72,
					"hz": "Mobile"
				},
				{
					"user": "Jeysun",
					"link": "https://www.youtube.com/watch?v=ex6rA4Z-dHo",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "Jef GD",
					"link": "https://youtu.be/7m9psqKY4jw",
					"percent": 61,
					"hz": "30hz"
				},
				{
					"user": "HowlingBolt",
					"link": "https://www.youtube.com/watch?v=GjvGF57XwTY&feature=youtu.be",
					"percent": 100,
					"hz": "300hz"
				},
				{
					"user": "YellowDoopAlt",
					"link": "https://omlet.gg/v/aPnaAwE5OFMvdtk1q",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "NutOn",
					"link": "https://www.youtube.com/watch?v=wxZpXuc959Q",
					"percent": 100,
					"hz": "120hz"
				},
				{
					"user": "bletzee",
					"link": "https://www.youtube.com/watch?v=CwQnvwGeCD4&t=1s",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "TsunaiKk",
					"link": "https://youtu.be/AUw-neCIeXY",
					"percent": 98,
					"hz": "Mobile"
				},
				{
					"user": "zekothewolf",
					"link": "https://www.youtube.com/watch?v=Lc98B8XlvP8",
					"percent": 100,
					"hz": "144hz"
				},
				{
					"user": "VeryCoolBeans",
					"link": "https://www.youtube.com/watch?v=_HRRQjAhLkI",
					"percent": 100,
					"hz": "Mobile"
				},
				{
					"user": "Kind1e",
					"link": "https://vimeo.com/445421003",
					"percent": 73,
					"hz": "Mobile"
				},
				{
					"user": "Ky",
					"link": "https://www.youtube.com/watch?v=3wT9jwTrlBo&feature=youtu.be",
					"percent": 100,
					"hz": "60hz"
				},
				{
					"user": "MacJubber",
					"link": "https://youtu.be/TaBU6nLbOKc",
					"percent": 100,
					"hz": "300hz"
				},
			],
			"name": "Shitty Xo Circles",
			"author": "AcropolisBoy",
			"more": "none",
			"id": 60160311,
			"pass": "Free to copy",
			"percentToQualify": 61,
			"verificationVid": "https://www.youtube.com/watch?v=qo9v8DgztNA",
			"key": 94
		},
		/*=================================================================================*/	
	
	],
	"version": [
		1,
		0,
		0
	]
};

const list = d.list;const version = d.version;
